package com.obc.quantity;

import src.Quantity;
import junit.framework.TestCase;

// Ensures correctness of Quantity
public class QuantityTest extends TestCase {

	private Quantity foot1;
	private Quantity inch12;

	protected void setUp() {
		foot1 = Quantity.foot(1);
		inch12 = Quantity.inch(12);
	}

	public void testSameUnitEquals() {
		assertEquals(foot1, Quantity.foot(1));
		assertFalse(foot1.equals(Quantity.foot(2)));
		assertFalse(foot1.equals(null));
		assertFalse(foot1.equals(new Object()));
	}

	public void testDifferentUnitEquals() {
		assertFalse(foot1.equals(Quantity.inch(1)));
		assertEquals(foot1, inch12);
		assertEquals(inch12, foot1);
	}
	
	public void testYardEquals() {
		assertEquals(Quantity.foot(3), Quantity.yard(1));
	}
	
	public void testWeightEquals() throws Exception {
		assertEquals(Quantity.gram(1), Quantity.gram(1));
		final Quantity kg1 = Quantity.kilogram(1);
		assertEquals(kg1, Quantity.kilogram(1));
		assertEquals(kg1, Quantity.gram(1000));
	}
	
	public void testWeightNotEqualsLength() throws Exception {
		assertFalse(Quantity.gram(1).equals(Quantity.inch(1)));
	}
}
