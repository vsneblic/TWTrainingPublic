﻿using System.Collections.Generic;
using NUnit.Framework;

namespace Graph.PathTo.Tests
{
    [TestFixture]
    public class NodeTest
    {
        private Node _nodeA;
        private Node _nodeB;
        private Node _nodeC;
        private Node _nodeX;

        [SetUp]
        public void SetUp()
        {
            _nodeA = new Node("A");
            _nodeB = new Node("B");
            _nodeC = new Node("C");
            _nodeX = new Node("X");
        }

        [Test]
        public void Path_to_self_should_be_empty_path()
        {
            Assert.That(_nodeA.PathTo(_nodeA), Is.EqualTo(Path.EmptyFrom(_nodeA)));
        }

        [Test]
        public void Path_to_a_non_existing_node_should_be_a_null_path()
        {
            Assert.That(_nodeA.PathTo(_nodeX), Is.EqualTo(Path.NonExisting));
        }

        [Test]
        public void Path_to_a_neighbor_should_contain_the_node_and_the_neighor()
        {
            _nodeA.AddNeighbor(_nodeB);

            var result = _nodeA.PathTo(_nodeB);

            Assert.That(result, Is.EqualTo(new Path(new List<Node>() {_nodeA, _nodeB})));
        }

        [Test]
        public void Path_to_a_neighbor_neighboor_should_contain_the_node_and_the_two_neighbors()
        {
            _nodeA.AddNeighbor(_nodeB);
            _nodeB.AddNeighbor(_nodeC);
            Assert.That(_nodeA.PathTo(_nodeC), Is.EqualTo(new Path(new List<Node>() {_nodeA, _nodeB, _nodeC})));
        }

        [Test]
        public void PathTo_CanReach_should_work_in_presence_of_cycles()
        {
            _nodeA.AddNeighbor(_nodeB);
            _nodeB.AddNeighbor(_nodeA);
 
            Assert.That(_nodeA.PathTo(_nodeX), Is.EqualTo(Path.NonExisting));            
        }

        [Test]
        public void PathTo_CanReach_should_work_in_presence_of_self_cycles()
        {
            _nodeA.AddNeighbor(_nodeA);

            Assert.That(_nodeA.PathTo(_nodeX), Is.EqualTo(Path.NonExisting));
        }
    }
}
