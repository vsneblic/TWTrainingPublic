﻿using System;
using System.Collections.Generic;

namespace ParkingLot1.Intro_Observer
{
    public class ParkingLot
    {
        private readonly int _capacity;
        private readonly List<Car> _parkedCarsList;
        private readonly List<IParkingLotObserver> _observers; 

        public ParkingLot(int capacity)
        {
            _capacity = capacity;
            _parkedCarsList = new List<Car>();
            _observers = new List<IParkingLotObserver>();
        }

        public bool HasAvailableSpace
        {
            get { return _parkedCarsList.Count < _capacity; }
        }

        public bool TwentyPercentOrLessFree
        {
            get { return _parkedCarsList.Count >= _capacity*8.0/10.0; }
        }

        public bool LastSpaceLeft
        {
            get { return _parkedCarsList.Count == _capacity - 1; }
        }

        public void Subscribe(IParkingLotObserver newObserver)
        {
            _observers.Add(newObserver);
        }

        public void ParkCar(Car carToPark)
        {
            if (_parkedCarsList.Contains(carToPark))
            {
                throw new InvalidOperationException("The car is already parked in the parking lot.");    
            }

            if (HasAvailableSpace == false)
            {
                throw new InvalidOperationException("The parking lot is full, no more cars admitted currently.");
            }

            _parkedCarsList.Add(carToPark);

            NotifyObservers();
        }

        public void RetrieveCar(Car car)
        {
            if (_parkedCarsList.Contains(car) == false)
            {
                throw new InvalidOperationException("Cars to retrieve is not parked here.");    
            }

            _parkedCarsList.Remove(car);

            NotifyObservers();
        }

        private void NotifyObservers()
        {
            foreach (var observer in _observers)
            {
                observer.ChangeNotification(this);
            }
        }
    }
}
