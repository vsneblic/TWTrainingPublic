package com.obc.graph;

import java.util.ArrayList;
import java.util.List;

// Understands its neighbours
public class Node {

	private final String name;
	private List<Node> neighbours = new ArrayList<Node>();
	private static final int UNREACHABLE = Integer.MAX_VALUE;

	public Node(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Node: " + name;
	}

	public boolean canReach(Node destination) {
		return (hopCount(destination, new ArrayList<Node>()) != UNREACHABLE); 
	}

	public void connect(Node neighbour) {
		neighbours.add(neighbour);
	}

	public int hopCount(Node destination) throws UnreachableNodeException {
		int hopCount = hopCount(destination, new ArrayList<Node>());
		if (hopCount != UNREACHABLE) return hopCount;
		throw new UnreachableNodeException("" + destination + " not connected to " + this);
	}

	private int hopCount(Node destination, List<Node> visited) {
		if (this == destination) return 0;
		if (visited.contains(this)) return UNREACHABLE;
		visited.add(this);
		int champion = UNREACHABLE; 
		for (Node neighbour : neighbours) {
			champion = Math.min(champion, neighbour.hopCount(destination, visited));
		}
		visited.remove(this);
		return champion == UNREACHABLE ? UNREACHABLE : champion + 1;
	}	
}
