package graph;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 	Understands a directed route between two Nodes. 
 */
public class Path {

	private static final int FRONT = 0;
	private Node origin;
	private final List<Link> links = new ArrayList<Link>();

	public int cost() {
		return Link.cost(links);
	}

	Path prepend(Link link) {
		links.add(FRONT, link);
		return this;
	}

	void origin(Node origin) {
		this.origin = origin;
	}

	int length() {
		return links.size();
	}
	
	static final Comparator<Path> SHORTEST = new Comparator<Path>() {

		public int compare(Path left, Path right) {
			return left.length() - right.length();
		}
		
	};

	static final Comparator<Path> CHEAPEST = new Comparator<Path>() {

		public int compare(Path left, Path right) {
			return left.cost() - right.cost();
		}
		
	};

}
