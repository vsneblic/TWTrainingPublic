package q3;

import static q3.Unit.*;
/**
 * Understand amounts in a metric.
 */

public class Measurement {

	private final int amount;
	private final Unit unit;

	public Measurement (Unit unit, int amount){
		this.amount = amount;
		this.unit = unit;

	}
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other == null) return false;
		if (this.getClass() != other.getClass()) return false;
		return (this.amount == ((Measurement)other).amountIn(this.unit));
	}
	private int amountIn(Unit base) {
		return unit.amountIn(amount, base);
	}
	public static Measurement teaspoon(int size){
		return new Measurement(TSP, size);
	}

	public static Measurement tablespoon(int size){
		return new Measurement(TBSP, size);
	}

	public static Measurement ounce(int size){
		return new Measurement(OZ, size);
	}

	public static Measurement cup(int size){
		return new Measurement(CUP, size);
	}

	public static Measurement pint(int size){
		return new Measurement(PINT, size);
	}

	public static Measurement quart(int size){
		return new Measurement(QUART, size);
	}
	public static Measurement gallon(int size){
		return new Measurement(GALLON, size);
	}


}
