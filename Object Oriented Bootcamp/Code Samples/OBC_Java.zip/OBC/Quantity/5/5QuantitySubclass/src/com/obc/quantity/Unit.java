package com.obc.quantity;

// Understands a metric
class Unit {

	private static final Object TEMPERATURE = new Object();
	private static final Object WEIGHT = new Object();
	private static final Object LENGTH = new Object();
	
	private static final int GRAMS_IN_KILOS = 1000;
	public static final Unit GRAM = new Unit(1, WEIGHT, "g");
	public static final Unit KG = new Unit(GRAMS_IN_KILOS, WEIGHT, "Kg");

	private static final int INCHES_IN_YARD = 36;
	private static final int INCHES_IN_FOOT = 12;

	public static final Unit INCH = new Unit(1, LENGTH, "in");
	public static final Unit YARD = new Unit(INCHES_IN_YARD, LENGTH, "yd");
	public static final Unit FOOT = new Unit(INCHES_IN_FOOT, LENGTH, "ft");

	public static final Unit CELSIUS = new Unit(1, -273, TEMPERATURE, "C");
	public static final Unit KELVIN = new Unit(1, 0, TEMPERATURE, "K");
	public static final Unit FAHRENHEIT = new Unit(5.0/9.0, -459.4, TEMPERATURE, "F");
	
	private final double numberOfBaseUnits;
	private final Object unitType;
	private String name;
	private final double offset;

	private Unit(double numberOfBaseUnits, Object unitType, String name) {
		this(numberOfBaseUnits, 0, unitType, name);
	}

	public Unit(double numberOfBaseUnits, double offset, Object unitType, String name) {
		this.numberOfBaseUnits = numberOfBaseUnits;
		this.offset = offset;
		this.unitType = unitType;
		this.name = name;
	}

	public double convertTo(double value, Unit toUnit) {
		return (value - offset)*numberOfBaseUnits/toUnit.numberOfBaseUnits + toUnit.offset;
	}

	public boolean comparableWith(Unit other) {
		return unitType == other.unitType;
	}

	public String toString() {
		return name;
	}
}