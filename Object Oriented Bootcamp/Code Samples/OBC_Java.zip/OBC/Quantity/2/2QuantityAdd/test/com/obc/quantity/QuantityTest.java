package com.obc.quantity;

import src.IncompatibleUnitsException;
import src.Quantity;
import junit.framework.TestCase;

// Ensures correctness of Quantity
public class QuantityTest extends TestCase {

	private Quantity foot1;
	private Quantity inch12;
	private Quantity gram1;

	protected void setUp() {
		foot1 = Quantity.Foot(1);
		inch12 = Quantity.Inch(12);
		gram1 = Quantity.Gram(1);
	}

	public void testSameUnitEquals() {
		assertEquals(foot1, Quantity.Foot(1));
		assertFalse(foot1.equals(Quantity.Foot(2)));
		assertFalse(foot1.equals(null));
		assertFalse(foot1.equals(new Object()));
	}

	public void testDifferentUnitEquals() {
		assertFalse(foot1.equals(Quantity.Inch(1)));
		assertEquals(foot1, inch12);
		assertEquals(inch12, foot1);
	}
	
	public void testYardEquals() {
		assertEquals(Quantity.Foot(3), Quantity.Yard(1));
	}
	
	public void testWeightEquals() {
		assertEquals(gram1, Quantity.Gram(1));
		final Quantity kg1 = Quantity.Kg(1);
		assertEquals(kg1, Quantity.Kg(1));
		assertEquals(kg1, Quantity.Gram(1000));
	}
	
	public void testWeightNotEqualsLength() {
		assertFalse(Quantity.Gram(1).equals(Quantity.Inch(1)));
	}
	
	public void testAdd()  {
		final Quantity foot2 = Quantity.Foot(2);
		assertEquals(foot2, foot1.add(foot1));
		assertEquals(foot2, foot1.add(inch12));
		assertEquals(Quantity.Kg(2), Quantity.Gram(1000).add(Quantity.Kg(1)));
	}
	
	public void testCannotAddALengthAndAWeight() {
		try {
			foot1.add(gram1);
			fail("Shouldn't be able to add a gram and a foot");
		} catch (IncompatibleUnitsException expected) {
		}
	}
}
