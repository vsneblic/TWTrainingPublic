module Bootcamp
  module Graph
  
    # Understands a connection from one Node to another
    class Link
      
      attr_reader :cost
    
      def initialize(targetNode, cost)
        @target, @cost = targetNode, cost
      end
      
      def _path(destination, visited_nodes, strategy)
        @target._path(destination, visited_nodes, strategy) << self
      end
        
    end
    
  end
end