package com.obc.quantity;

public class Quantity {

	public static Quantity celsius(double numberOfDegreesCelsius) {
		return new Quantity(numberOfDegreesCelsius, Unit.CELSIUS);
	}

	public static Quantity kelvin(double numberOfDegreesKelvin) {
		return new Quantity(numberOfDegreesKelvin, Unit.KELVIN);
	}

	public static Quantity fahrenheit(double numberOfDegreesFahreheit) {
		return new Quantity(numberOfDegreesFahreheit, Unit.FAHRENHEIT);
	}

	protected final double value;
	protected final Unit unit;

	protected Quantity(double value, Unit unit) {
		this.value = value;
		this.unit = unit;
	}

	public String toString() {
		return "" + value + " " + unit;
	}

	public boolean equals(Object other) {
		if ((other == null) || other.getClass() != getClass())
			return false;
		final Quantity otherQuantity = ((Quantity) other);
		if (!unit.comparableWith(otherQuantity.unit)) return false; 
		return Math.abs(value - otherQuantity.convertTo(unit)) <= 0.001;
	}

	protected double convertTo(Unit toUnit) {
		return unit.convertTo(value, toUnit);
	}

}