﻿using NUnit.Framework;

namespace ParkingLot3.Visitor.Tests
{
    [TestFixture]
    public class ReportersTest
    {
        private Attendant _attendant;
        private Attendant _cousin;
        private Attendant _employee;
        private Attendant _uncle;

        private ParkingLot _emptyParkingLot;
        private ParkingLot[] _parkingLot;

        [SetUp]
        public void SetUp()
        {
            _attendant = new Attendant();
            _cousin = new Attendant();
            _employee = new Attendant();
            _uncle = new Attendant();

            _attendant.Attend(_cousin);
            _attendant.Attend(_uncle);
            _cousin.Attend(_employee);

            _emptyParkingLot = new ParkingLot(capacity: 10);

            _parkingLot = new ParkingLot[8];
            for (int i = 0; i < 4; i++)
            {
                _parkingLot[i] = new ParkingLot(capacity: 10);
                for (int j = 0; j <= i; j++)
                {
                    _parkingLot[i].ParkCar(new Car());                        
                }
            }

            _attendant.Attend(_parkingLot[0]);

            _cousin.Attend(_parkingLot[1]);
            _cousin.Attend(_emptyParkingLot);

            _employee.Attend(_parkingLot[2]);
            _employee.Attend(_emptyParkingLot);

            _uncle.Attend(_parkingLot[3]);
            _uncle.Attend(_emptyParkingLot);
        }
 
        [Test]
        public void CarsCountReporterTourTest()
        {
            var reporter = new CarsCountReporter();
            _attendant.ParkingServicesTour(reporter);

            const string expectedReport = "Parking Lot A: available spaces 7.\n" +
                                          "Parking Lot B: available spaces 10.\n" +
                                          "Parking Lot C: available spaces 8.\n" +
                                          "Parking Lot D: available spaces 6.\n" +
                                          "Parking Lot E: available spaces 9.\n";

            Assert.That(reporter.Report, Is.EqualTo(expectedReport));
        }

        [Test]
        public void ParkingLotsAndAttendantsReporterTourTest()
        {
            var reporter = new ParkingLotsAndAttendantsReporter();
            _attendant.ParkingServicesTour(reporter);

            const string expectedReport = "Attendant 0 { Attendant 1 { Attendant 2 { Parking Lot A: capacity 10; Parking Lot B: capacity 10; } Parking Lot C: capacity 10; } Attendant 3 { Parking Lot D: capacity 10; } Parking Lot E: capacity 10; } ";

            Assert.That(reporter.Report, Is.EqualTo(expectedReport));
        }
    }
}
