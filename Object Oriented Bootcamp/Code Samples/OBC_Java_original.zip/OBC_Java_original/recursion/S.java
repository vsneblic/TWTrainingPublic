package recursion;

/**
 * 	Understands string manipulation.
 */
public class S {

	private static final int EMPTY = 0;
	private static final int HEAD = 0;
	private static final int TAIL = 1;
	private static final int NO_TAIL = 1;
	private final String s;

	public S(String s) {
		this.s = s;
	}

	public S reverse() {
		return tail().reverse(head());
	}

	private S reverse(char c) {
		if (isBlank()) return this.concat(c);
		return tail().reverse(head()).concat(c);
	}

	private boolean isBlank() {
		return s.length() == EMPTY;
	}

	private S tail() {
		if (hasNoTail()) return new S("");
		return new S(s.substring(TAIL));
	}

	private boolean hasNoTail() {
		return s.length() == NO_TAIL;
	}

	private char head() {
		return s.charAt(HEAD);
	}
	
	private S concat(char c) {
		return new S(s.concat(String.valueOf(c)));
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other == null) return false;
		if (this.getClass() != other.getClass()) return false;
		return this.equals((S)other);
	}
	
	private boolean equals(S other) {
		return s.equals(other.s);
	}
	
	@Override
	public String toString() {
		return s;
	}
}
