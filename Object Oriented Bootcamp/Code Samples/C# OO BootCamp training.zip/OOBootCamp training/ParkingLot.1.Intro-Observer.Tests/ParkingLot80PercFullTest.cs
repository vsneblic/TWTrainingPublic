﻿using NUnit.Framework;

namespace ParkingLot1.Intro_Observer.Tests
{
    [TestFixture]
    public class ParkingLot80PercFullTest
    {
        [Test]
        public void When_there_are_more_than_20perc_free_parking_places_then_TwentyPercentOrLessFree_should_be_false()
        {
            var target = new ParkingLot(capacity: 9);
            ParkCars(target, numberOfCars: 7);

            Assert.That(target.TwentyPercentOrLessFree, Is.False);
        }

        [Test]
        public void When_there_are_20perc_free_parking_places_then_TwentyPercentOrLessFree_should_be_true()
        {
            var target = new ParkingLot(capacity: 10);
            ParkCars(target, numberOfCars: 8);

            Assert.That(target.TwentyPercentOrLessFree, Is.True);
        }

        [Test]
        public void When_there_are_less_then_20perc_free_parking_places_then_TwentyPercentOrLessFree_should_be_true()
        {
            var target = new ParkingLot(capacity: 9);
            ParkCars(target, numberOfCars: 8);

            Assert.That(target.TwentyPercentOrLessFree, Is.True);
        }

        private static void ParkCars(ParkingLot target, int numberOfCars)
        {
            for (int i = 1; i <= numberOfCars; i++)
            {
                target.ParkCar(new Car());
            }
        }

    }
}
