package parking;

/**
 * 	Understands communication of a ParkingLot being full.
 */
public class ParkingLotFullException extends RuntimeException {
	
	
	public ParkingLotFullException(int capacity) {
		super("Parking lot capacity of " + capacity + " has been reached.");
	}

	private static final long serialVersionUID = -4617049472146237006L;

}
