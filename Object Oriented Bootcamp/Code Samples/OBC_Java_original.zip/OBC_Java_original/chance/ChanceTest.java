package chance;

import static org.hamcrest.core.IsNot.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import org.junit.Test;

/**
 * 	Ensures the correctness of Chance.
 */

public class ChanceTest {
	private static final Chance CERTAIN = new Chance(1);
	private static final Chance IMPOSSIBLE = new Chance(0);
	private static final Chance LIKELY = new Chance(0.75);
	private static final Chance UNLIKELY = new Chance(0.25);
	private static final Chance EQUALY_LIKELY = new Chance(0.5);
	private static final Object VERY_LIKELY = new Chance(0.8125);
	private static final Object ALMOST_CERTAIN = new Chance(0.9375);
	

	@Test
	public void shouldNot() {
		assertEquals(IMPOSSIBLE, CERTAIN.not());
		assertEquals(CERTAIN, IMPOSSIBLE.not());
		assertEquals(UNLIKELY, LIKELY.not());
		assertEquals(CERTAIN, CERTAIN.not().not());
		assertEquals(IMPOSSIBLE, IMPOSSIBLE.not().not());
		assertEquals(LIKELY, LIKELY.not().not());
		assertEquals(UNLIKELY, UNLIKELY.not().not());

        assertThat(UNLIKELY, not(LIKELY));
	}
	
	@Test
	public void shouldAnd() {
		assertEquals(LIKELY, LIKELY.and(CERTAIN));
		assertEquals(LIKELY, CERTAIN.and(LIKELY));
		assertEquals(IMPOSSIBLE, LIKELY.and(IMPOSSIBLE));
		assertEquals(IMPOSSIBLE, IMPOSSIBLE.and(LIKELY));
	}
	
	@Test
	public void shouldOr() {
		assertEquals(IMPOSSIBLE, IMPOSSIBLE.or(IMPOSSIBLE));
		assertEquals(CERTAIN, CERTAIN.or(CERTAIN));
		assertEquals(CERTAIN, CERTAIN.or(IMPOSSIBLE));
		assertEquals(CERTAIN, IMPOSSIBLE.or(CERTAIN));
		assertEquals(LIKELY, EQUALY_LIKELY.or(EQUALY_LIKELY));
		assertEquals(ALMOST_CERTAIN, LIKELY.or(LIKELY));
		assertEquals(VERY_LIKELY, LIKELY.or(UNLIKELY));
		assertEquals(VERY_LIKELY, UNLIKELY.or(LIKELY));

	}
}
