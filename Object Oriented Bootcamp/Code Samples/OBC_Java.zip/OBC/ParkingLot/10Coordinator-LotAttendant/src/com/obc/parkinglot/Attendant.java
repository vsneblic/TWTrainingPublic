package com.obc.parkinglot;

import java.util.ArrayList;
import java.util.List;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

// Understands a person responsible for parking lots
public class Attendant implements ParkingLotObserver {

	private List<ParkingLot> allLots = new ArrayList<ParkingLot>();
	private List<ParkingLot> availableLots = new ArrayList<ParkingLot>();
	private LotSelectionMethod lotSelectionMethod;
	
	public Attendant(LotSelectionMethod lotSelectionMethod) {
		this.lotSelectionMethod = lotSelectionMethod;
	}

	public void responsibleFor(ParkingLot lot) {
		allLots.add(lot);
		lot.addObserver(this);
		if (!lot.isFull())
			availableLots.add(lot);
	}

	public Object direct(Object car) throws CannotParkException {
		return direct(car, lotSelectionMethod);
	}
	
	public Object direct(Object car, LotSelectionMethod lotSelectionMethod) throws CannotParkException {
		if (availableLots.isEmpty())
			throw CannotParkException.becauseAllLotsAreFull(car, this);
		return lotSelectionMethod.selectLotToParkInto(availableLots).park(car);
	}


	public Object unpark(Object token) throws CannotUnparkException {
		for (ParkingLot lot : allLots) {
			if (lot.hasCarFor(token))
				return lot.unpark(token);
		}
		throw new CannotUnparkException(token, this);
	}

	public void notifyFull(ParkingLot lot) {
		availableLots.remove(lot);
	}

	public void notifyHasSpace(ParkingLot lot) {
		availableLots.add(lot);
	}

	public static Attendant firstLotParker() {
		return new Attendant(LotSelectionMethod.FIRST_AVAILABLE);
	}

	public static Attendant mostFreeLotParker() {
		return new Attendant(LotSelectionMethod.MOST_FREE);
	}

	public static Attendant mostCapacityLotParker() {
		return new Attendant(LotSelectionMethod.MOST_CAPACITY);
	}
} 

