package com.obc.parkinglot;

// understands the contract interested parties need to follow 
// to be notified of changes in ParkingSpace
interface ParkingSpaceObserver {

	public abstract void notifyFull(ParkingSpace space);

	public abstract void notifyHasSpace(ParkingSpace space);

}