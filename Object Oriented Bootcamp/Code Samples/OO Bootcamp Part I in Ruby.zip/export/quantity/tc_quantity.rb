$:.unshift File.dirname(__FILE__)
module Bootcamp
  module Quantity
    require 'test/unit'
    require 'quantity'
    require 'arithmetic_quantity'
    require 'unit'
    require 'arithmetic_unit'
    require 'incompatible_metrics_error'

    # Ensures Quantity operates correctly.
    class TestQuantity < Test::Unit::TestCase
      
      def test_equality_for_same_unit
        assert_equal($PINT.s(2), $PINT.s(2))
        assert_equal($QUART.s(6), $QUART.s(6))
        assert_not_equal($PINT.s(2), $PINT.s(3))
      end
      
      def test_equality_for_different_units
        assert_equal($QUART.s(2), $PINT.s(4))
        assert_equal($PINT.s(4), $QUART.s(2))
      end
      
      def test_addition
        assert_equal($PINT.s(6), $PINT.s(2) + $QUART.s(2))
        assert_equal($PINT.s(6), $QUART.s(2) + $PINT.s(2))
      end
      
      def test_negation
        assert_equal($PINT.s(-6), -$PINT.s(6))
        assert_equal($PINT.s(-8), -$QUART.s(4))
      end
      
      def test_subtraction
        assert_equal($PINT.s(-2), $PINT.s(2) - $QUART.s(2))
        assert_equal($PINT.s(2), $QUART.s(2) - $PINT.s(2))
      end
      
      def test_incompatible
        assert_not_equal($OUNCE.s(1), $INCH.es(1))
      end
      
      def test_raises_incompatible_metrics
        assert_raise(IncompatibleMetricsError) do
          $YARD.s(2) - $CUP.s(2)
        end
      end
      
      def test_temperature
        assert_equal($CELCIUS.degrees(0), $FAHRENHEIT.degrees(32))
        assert_equal($CELCIUS.degrees(-40), $FAHRENHEIT.degrees(-40))
        assert_equal($CELCIUS.degrees(100), $FAHRENHEIT.degrees(212))
        assert_equal($FAHRENHEIT.degrees(32), $CELCIUS.degrees(0))
        assert_equal($FAHRENHEIT.degrees(-40), $CELCIUS.degrees(-40))
        assert_equal($FAHRENHEIT.degrees(212), $CELCIUS.degrees(100))
      end
      
      def test_no_method_for_arithmetic
        assert_raise(NoMethodError) do
          $CELCIUS.degrees(6) + $CELCIUS.degrees(10)
        end
      end
      
    end
  end
end