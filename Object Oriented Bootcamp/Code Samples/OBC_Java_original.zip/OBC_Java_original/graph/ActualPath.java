package graph;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 	Understands a directed route between two Nodes. 
 */
public class ActualPath {

	private static final int FRONT = 0;
	Node origin;
	private final List<Link> links = new ArrayList<Link>();

	public int cost() {
		return Link.cost(links);
	}

	public ActualPath prepend(Link link) {
		links.add(FRONT, link);
		return this;
	}

	public void origin(Node origin) {
		this.origin = origin;
	}

	int length() {
		return links.size();
	}
	
	public static final Comparator<ActualPath> SHORTEST = new Comparator<ActualPath>() {

		public int compare(ActualPath left, ActualPath right) {
			return left.length() - right.length();
		}
		
	};

	public static final Comparator<ActualPath> CHEAPEST = new Comparator<ActualPath>() {

		public int compare(ActualPath left, ActualPath right) {
			return left.cost() - right.cost();
		}
		
	};

}
