﻿namespace ParkingLot2.Composite
{
    public interface IParkingLotObserver
    {
        void ChangeNotification(ParkingLot sender);
    }
}