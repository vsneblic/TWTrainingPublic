﻿using NUnit.Framework;

namespace QuantityLength2WithInheritance.Tests
{
    [TestFixture]
    public class LengthAddTest
    {

        [Test]
        public void Adding_two_lengths_in_inches_return_the_sum()
        {
            var result = new LengthInInches(10) + new LengthInInches(1);

            var expectedResult = new LengthInInches(11);

            Assert.That(result.IsEquivalentTo(expectedResult), Is.True);
        }

        [Test]
        public void Adding_two_lengths_in_feet_return_the_sum()
        {
            var result = new LengthInFeet(10) + new LengthInFeet(1);

            var expectedResult = new LengthInFeet(11);

            Assert.That(result.IsEquivalentTo(expectedResult), Is.True);
        }

        [Test]
        public void Adding_two_lengths_in_miles_return_the_sum()
        {
            var result = new LengthInMile(10) + new LengthInMile(1);

            var expectedResult = new LengthInMile(11);

            Assert.That(result.IsEquivalentTo(expectedResult), Is.True);
        }

        [Test]
        public void Adding_two_lengths_in_yards_return_the_sum()
        {
            var result = new LengthInMile(10) + new LengthInMile(1);

            var expectedResult = new LengthInMile(11);

            Assert.That(result.IsEquivalentTo(expectedResult), Is.True);
        }

    }
}
