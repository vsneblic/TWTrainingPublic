﻿

using System.Collections.Generic;
using System.Linq;

namespace Graph.PathTo
{
    public class Node
    {
        private readonly string _name;
        private readonly List<Node> _neightbors;

        public Node(string name) : this(name, new Node[0])
        {
        }

        public Node(string name, IEnumerable<Node> neightbors)
        {
            _name = name;
            _neightbors = new List<Node>(neightbors);
        }

        public string Name
        {
            get { return _name; }
        }
        
        public void AddNeighbor(Node neighborNode)
        {
            _neightbors.Add(neighborNode);
        }


        public bool CanReach(Node destination)
        {
            return CanReach(destination, new List<Node>());
        }

        private bool CanReach(Node destination, List<Node> visitedNodes)
        {
            visitedNodes.Add(this);

            return this == destination || _neightbors.Except(visitedNodes).Any(node => node.CanReach(destination, visitedNodes));
        }

        public Path PathTo(Node destination)
        {
            return PathTo(destination, new List<Node>());
        }

        private Path PathTo(Node destination, List<Node> visitedNodes)
        {
            var startingPoint = Path.EmptyFrom(this);
            if (destination == this)
            {
                return startingPoint;
            }

            visitedNodes.Add(this);

            foreach (var neighbor in _neightbors.Except(visitedNodes))
            {
                var pathFromNeighbor = neighbor.PathTo(destination, visitedNodes);
                if (pathFromNeighbor != Path.NonExisting)
                {
                    return startingPoint + pathFromNeighbor;
                }
            }

            return Path.NonExisting;
        }

    }
}
