package q3;
/**
 * Ensures the correctness of Measurement.
 */
import static org.junit.Assert.assertEquals;
import static q3.Measurement.cup;
import static q3.Measurement.gallon;
import static q3.Measurement.ounce;
import static q3.Measurement.pint;
import static q3.Measurement.quart;
import static q3.Measurement.tablespoon;
import static q3.Measurement.teaspoon;

import org.junit.Test;


	public class MeasurementTest {
		@Test
		public void shouldBeAbleToDetermineVolumeConversion() throws Exception {
			assertEquals(teaspoon(0),teaspoon(0));
			assertEquals(teaspoon(1),teaspoon(1));

			assertEquals(teaspoon(0),tablespoon(0));
			assertEquals(teaspoon(3),tablespoon(1));

			assertEquals(tablespoon(2),ounce(1));

			assertEquals(teaspoon(12),ounce(2));

			assertEquals(ounce(8),cup(1));
			assertEquals(cup(2),pint(1));
			assertEquals(cup(4),quart(1));
			assertEquals(pint(2),quart(1));
			assertEquals(quart(4),gallon(1));
			assertEquals(gallon(1),quart(4));
			assertEquals(gallon(1),pint(8));
	}
}
