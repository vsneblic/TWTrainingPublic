﻿using System;
using NUnit.Framework;

namespace ParkingLot1.Intro_Observer.Tests
{
    [TestFixture]
    public class ParkingLotObserversTest
    {
        private ParkingLot _parkingLot;
        private ParkingLotTestObserver _observer;
        private Car _car;

        [SetUp]
        public void SetUp()
        {
            _parkingLot = new ParkingLot(capacity: 3);
            _observer = new ParkingLotTestObserver();
            _car = new Car();
        }

        [Test]
        public void When_a_car_park_an_observer_should_be_notified()
        {
            _parkingLot.Subscribe(_observer);

            _parkingLot.ParkCar(_car);

            Assert.That(_observer.NotificationsCount, Is.EqualTo(1));
        }

        [Test]
        public void When_a_car_is_retrieved_an_observer_should_be_notified()
        {

            _parkingLot.ParkCar(_car);

            _parkingLot.Subscribe(_observer);

            _parkingLot.RetrieveCar(_car);

            Assert.That(_observer.NotificationsCount, Is.EqualTo(1));
        }

        [Test]
        public void When_a_car_parking_raise_an_error_the_observer_should_not_notified()
        {
            _parkingLot.ParkCar(_car);
            _parkingLot.Subscribe(_observer);
            var sameCar = _car;

            try
            {
                _parkingLot.ParkCar(sameCar);
            }
            catch
            {
                // Ignore double parking error
            }


            Assert.That(_observer.NotificationsCount, Is.EqualTo(0));
        }

        [Test]
        public void When_a_car_retrieving_raise_an_error_the_observer_should_not_notified()
        {
            _parkingLot.Subscribe(_observer);

            try
            {
                _parkingLot.RetrieveCar(_car);
            }
            catch
            {
                // Ignore non parked car retrienving error
            }


            Assert.That(_observer.NotificationsCount, Is.EqualTo(0));
        }

        private class ParkingLotTestObserver : IParkingLotObserver
        {
            public int NotificationsCount { get; private set; }

            public void ChangeNotification(ParkingLot sender)
            {
                NotificationsCount += 1;
            }
        }
    }
}
