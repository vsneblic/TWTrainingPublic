package parking;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 	Understands the temporary storage of cars.
 */
public class ParkingLot extends ParkingSpaces {

	private static final int OLDEST = 0;
	private final int capacity;
	private List<Object> cars = new ArrayList<Object>();
	Collection<ParkingLotObserver> observers = new ArrayList<ParkingLotObserver>();

	public ParkingLot(String name, int capacity) {
		super(name);
		this.capacity = capacity;
	}

	public boolean canPark() {
		return cars.size() < capacity;
	}

	public void park(Object car) {
		if (!canPark()) throw new ParkingLotFullException(capacity);
		cars.add(car);
		for (ParkingLotObserver observer : observers)
			observer.notify(cars.size(), capacity, this);
	}
	
	public void remove(Object car) {
		if (!cars.remove(car)) throw new CarNotFoundException(car);
		for (ParkingLotObserver observer : observers)
			observer.notify(cars.size(), capacity, this);
	}

	public Object tow() {
		return cars.remove(OLDEST);
	}

	void addObserver(ParkingLotObserver attendant) {
		this.observers.add(attendant);
		attendant.notify(cars.size(), capacity, this);
	}

	boolean contains(Object car) {
		return cars.contains(car);
	}

	int percentFull() {
		return 1000 * cars.size()/capacity;
	}

//	String printStructure() {
//		return name + " ";
//	}

	public void accept(ParkingLotVisitor visitor) {
		visitor.visit(this);
	}

	int carCount() {
		return cars.size();
	}

}
