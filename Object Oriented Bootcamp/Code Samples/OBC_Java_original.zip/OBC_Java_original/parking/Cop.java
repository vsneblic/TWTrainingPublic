package parking;

public class Cop implements ParkingLotObserver {

	private static final int THRESHOLD = 1;
	private final AutoPound pound;

	public Cop(ParkingLot lot, AutoPound pound) {
		lot.addObserver(this);
		pound.addObserver(this);
		this.pound = pound;
	}

	public void notify(int cars, int capacity, ParkingLot lot) {
		if (capacity - cars == THRESHOLD)
			pound.park(lot.tow());
	}
}
