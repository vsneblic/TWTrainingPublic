module Bootcamp
  module Graph
    
    # Understands its neighors
    class Node
    
      def initialize(name)
        @name = name
        @links = []
      end
      
      def connect_to(neighbor, cost = 0)
        @links << Link.new(neighbor, cost)
      end
      
      def reach?(destination)
        !paths(destination).empty?
      end

      def hop_count(destination)
        non_empty_paths(destination).min {|a, b| a.hop_count <=> b.hop_count}.hop_count
      end

      def cost(destination)
        path(destination).cost
      end

      def path(destination)
        non_empty_paths(destination).min {|a, b| a.cost <=> b.cost}
      end

      private
      def non_empty_paths(destination)
        results = paths(destination)
        raise NoPathError if results.empty?
        results
      end
      
      public
      def paths(destination)
        _paths(destination).each {|p| p.source = self}
      end
      
      def _paths(destination, visited_nodes = [])
        return [Path.new] if self == destination
        return [] if visited_nodes.include?(self) || @links.empty?
        (visited_nodes = visited_nodes.dup) << self
        @links.inject([]) {|results, link| results + link._paths(destination, visited_nodes)}
      end
      
    end

  end
end