package q3;

/**
 * 	Understands a specific metric.
 */
public class Unit {
	private final int ratio;
	
	public Unit(int ratio) {
		this.ratio = ratio;
	}
	
	static final Unit TSP = new Unit(1);
	static final Unit TBSP = new Unit(3);
	static final Unit OZ = new Unit(6);
	static final Unit CUP = new Unit(48);
	static final Unit PINT = new Unit(96);
	static final Unit QUART = new Unit(192);
	static final Unit GALLON = new Unit(768);

	public int amountIn(int amount, Unit base) {
		return amount*ratio/base.ratio;
	}

}
