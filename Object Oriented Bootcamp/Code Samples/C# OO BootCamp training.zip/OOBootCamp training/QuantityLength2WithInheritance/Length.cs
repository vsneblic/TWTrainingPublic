﻿
using System;

namespace QuantityLength2WithInheritance
{
    public abstract class Length
    {

        private readonly double _value;
        private readonly double _conversionFactorToInches;

        protected Length(double value, double conversionFactorToInches)
        {
            _value = value;
            _conversionFactorToInches = conversionFactorToInches;
        }

        public bool IsEquivalentTo(Length other)
        {
            return ToInches() == other.ToInches();
        }

        protected double SumUpWithTheValueOf(Length length)
        {
            return _value + length._value;
        }

        private double ToInches()
        {
            return _value * _conversionFactorToInches;
        }
    }
}
