﻿namespace QuantityLength2WithInheritance
{
    public class LengthInInches : Length
    {
        public LengthInInches(double value) : base(value, 1.0) {}

        public static LengthInInches operator +(LengthInInches leftValue, LengthInInches rightValue)
        {
            return new LengthInInches(leftValue.SumUpWithTheValueOf(rightValue));
        }
    }
}