module Bootcamp
  module Graph
    
    # Understands its neighors
    class Node
      NO_PATH = 1.0/0.0
    
      def initialize(name)
        @name = name
        @links = []
      end
      
      def connect_to(neighbor, cost=0)
        @links << Link.new(neighbor, cost)
      end
      
      def reach?(destination)
        _hop_count(destination, []) != NO_PATH
      end

      def hop_count(destination)
        result = _hop_count(destination, [])
        raise NoPathError.new(self, destination) if result == NO_PATH
        result
      end
      
      def _hop_count(destination, visited_nodes)
        return 0 if self == destination
        return NO_PATH if visited_nodes.include?(self) || @links.empty?
        (visited_nodes = visited_nodes.dup) << self
        @links.collect {|link| link._hop_count(destination, visited_nodes)}.min
      end
      
    end

  end
end