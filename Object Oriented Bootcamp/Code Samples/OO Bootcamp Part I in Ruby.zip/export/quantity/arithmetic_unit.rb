module Bootcamp
  module Quantity

    # Understands a specific metric that supports arithmetic
    class ArithmeticUnit < Unit
      
      attr_reader :base_amount, :offset, :metric_type
      protected :base_amount, :offset, :metric_type
      
      $VOLUME = Object.new
      $OUNCE = ArithmeticUnit.new($VOLUME, "ounces", 1)
      $CUP = ArithmeticUnit.new($VOLUME, "cups", 8 * 1)
      $PINT = ArithmeticUnit.new($VOLUME, "pints", 2 * 8 * 1)
      $QUART = ArithmeticUnit.new($VOLUME, "quarts", 2 * 2 * 8 * 1)
      
      $DISTANCE = Object.new
      $INCH = ArithmeticUnit.new($DISTANCE, "inches", 1)
      $FOOT = ArithmeticUnit.new($DISTANCE, "feet", 12 * 1)
      $YARD = ArithmeticUnit.new($DISTANCE, "yards", 3 * 12 * 1)
      $MILE = ArithmeticUnit.new($DISTANCE, "miles", 1760 * 3 * 12 * 1)
      
      private_class_method :new
      
      def amount(value) 
        ArithmeticQuantity.new(value, self)
      end
      
      def s(value)
        amount(value)
      end
      
      def es(value)
        amount(value)
      end
      
    end
    
    class Unit
      private_class_method :new  # ArithmeticUnit has finished with it -- lock it down!
    end
    
  end
end