module Bootcamp
  module Graph
  
    # Understands a connection from one Node to another
    class Link
      
      attr_reader :cost
    
      def initialize(targetNode, cost)
        @target, @cost = targetNode, cost
      end
      
      def _paths(destination, visited_nodes = [])
        @target._paths(destination, visited_nodes).each {|p| p << self}
      end
        
    end
    
  end
end