package q2;

public class Quantity {
	static final Object TSP_ID = new Object();
	static final Quantity TSP = new Quantity(TSP_ID, 1);

	public Quantity(Object type, int amount) {
		
	}

}
