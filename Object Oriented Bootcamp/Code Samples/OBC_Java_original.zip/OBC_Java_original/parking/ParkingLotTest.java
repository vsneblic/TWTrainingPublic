package parking;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * 	Ensures the correctness of ParkingLot.
 */

public class ParkingLotTest {
	private final ParkingLot lot1 = new ParkingLot("Lot1", 1);
	private final ParkingLot lot2 = new ParkingLot("Lot2", 2);
	private final ParkingLot lot3 = new ParkingLot("Lot3", 3);
	private final ParkingLot lot5 = new ParkingLot("Lot5", 5);
	private final ParkingLot lot7 = new ParkingLot("Lot7", 7);
	private final ParkingLot lot10 = new ParkingLot("Lot10", 10);
	private final ParkingLot lot11 = new ParkingLot("Lot11", 11);
	private final ParkingLot lot13 = new ParkingLot("Lot13", 13);
	private final ParkingLot lot17 = new ParkingLot("Lot17", 17);
//	private Cop cop = new Cop();
	private ParkingLot observedLot;

	@Test
	public void shouldParkCars() {
		park(10, lot10);
		assertFull(lot10);
	}

	@Test
	public void shouldLeave() {
		Object car = car();
		lot10.park(car);
		lot10.remove(car);
		assertMissingCar(lot10, car);
	}
	
	@Test
	public void shouldNotifyWhenAttendantParks() {
		Attendant attendant = new Attendant(lot10);
		park(8, attendant);
		assertNotified(attendant);
		assertTrue(lot10.canPark());
	}
	
	@Test
	public void shouldNotifyWhenIndividualParks() {
		Attendant attendant = new Attendant(lot10);
		park(8, lot10);
		assertNotified(attendant);
		assertTrue(lot10.canPark());
	}
	
	@Test
	public void shouldNotifyWhenAttendantRemoves() {
		Attendant attendant = new Attendant(lot10);
		park(7, attendant);
		Object car = car();
		attendant.park(car);
		attendant.remove(car);
		assertTrue(attendant.canPark());
	}
	
	@Test
	public void shouldNotifyWhenIndividualLeaves() {
		Attendant attendant = new Attendant(lot10);
		park(7, attendant);
		Object car = car();
		attendant.park(car);
		lot10.remove(car);
		assertTrue(attendant.canPark());
	}
	
	@Test
	public void shouldAllowAttendantsToWatchPreviouslyFilledLot() {
		Attendant attendant = new Attendant(lot10);
		park(8, attendant);
		Attendant nightAttendant = new Attendant(lot10);
		//nightAttendant.watch(lot10);
		assertNotified(nightAttendant);
	}
	
	@Test
	public void shouldBeAbleToTowSelfParkedCars() {
		AutoPound autoPound = new AutoPound(); 
		new Attendant(autoPound) {
			public void notify(int cars, int capacity, ParkingLot lot) {
				observedLot = lot;
			}
		};
		observedLot = null;
		new Cop(lot10, autoPound);
		park(10, lot10);
		assertTrue(lot10.canPark());
		assertEquals(2, autoPound.percentFull());
		assertEquals(autoPound, observedLot);
	}
	
	@Test
	public void shouldBeAbleToTowAttendantParkedCars() {
		AutoPound autoPound = new AutoPound(); 
		new Attendant(autoPound) {
			public void notify(int cars, int capacity, ParkingLot lot) {
				observedLot = lot;
			}
		};
		observedLot = null;
		new Cop(lot5, autoPound);
		Attendant attendant = new Attendant(lot5);
		park(5, attendant);
		assertTrue(lot5.canPark());
		assertEquals(2, autoPound.percentFull());
		assertEquals(autoPound, observedLot);
	}
	
	@Test
	public void shouldWatchMultipleLots() {
		Attendant attendant = new Attendant(lot10, lot5);
		park(12, attendant);
		assertNotified(attendant);
	}
	
	@Test
	public void shouldFillLeastPercentFullLotFirst() {
		Attendant attendant = new Attendant(lot2, lot3, lot5);
		park(3, attendant);
		assertNext(attendant, lot5, lot3, lot5, lot2, lot5, lot3);
		assertFull(attendant);
	}
	
	@Test
	public void shouldBeAbleToHireAnEmployee() {
		Attendant employee = new Attendant(lot7, lot5);
		Attendant attendant = new Attendant(lot2, lot3, employee);
		park(4, attendant);
		assertNext(attendant, lot7, lot5, lot7, lot3, lot5, lot7, lot2, lot7, lot5, lot3, lot7);
		assertFull(attendant);
	}
	
	@Test
	public void shouldAllowEmployeesToHireEmployees() {
		Attendant attendant = attendant();
		park(8, attendant);
		assertNext(attendant, lot17, lot13, lot11, lot17, lot7, lot13, lot17, lot11, lot5, lot13, lot17, lot11, lot7, lot17, lot13, lot3, lot17, lot11, lot13, lot5, lot17, lot7, lot11, lot13, lot17);
		assertNext(attendant, lot2, lot17, lot13, lot11, lot7, lot17, lot5, lot13, lot11, lot17, lot3, lot13, lot17, lot7, lot11);
		assertNext(attendant, lot17, lot13);
		assertFull(attendant);
	}

	@Test
	public void shouldBeAbleToCountCars() {
		Attendant attendant = attendant();
		    assertEquals("0", attendant.printCarCount());
		    park(3, attendant);
		    assertEquals("3", attendant.printCarCount());
		    park(14, attendant);
		    assertEquals("17", attendant.printCarCount());
	}

	@Test
	public void shouldBeAbleToPrintParkingStructure() throws Exception {
		Attendant attendant = attendant();
		assertEquals("{ Attendant Lot2 Lot3 { Cousin Lot7 Lot5 { Employee Lot13 Lot17 } } { Uncle Lot1 Lot11 } } ", attendant.printStructure());
	}

	private Object car() {
		return new Object();
	}

	private Attendant attendant() {
		Attendant uncle = new Attendant("Uncle", lot1, lot11);
		Attendant employee = new Attendant("Employee", lot13, lot17);
		Attendant cousin = new Attendant("Cousin", lot7, lot5, employee);
		Attendant attendant = new Attendant("Attendant", lot2, lot3, cousin, uncle);
		return attendant;
	}
	
	private void park(int cars, ParkingLot lot) {
		for (int i = 0; i < cars; i++)
			lot.park(car());
	}

	private void park(int cars, ParkingSpaces attendant) {
		for (int i = 0; i < cars; i++)
			attendant.park(car());
	}

	private void assertFull(ParkingLot lot) {
		try {
			assertFalse(lot.canPark());
			lot.park(car());
			fail("Expected lot to be full.");
		}
		catch (ParkingLotFullException e) {}
	}

	private void assertFull(ParkingSpaces attendant) {
		try {
			assertFalse(attendant.canPark());
			attendant.park(car());
			fail("Expected all lots to be full.");
		}
		catch (NoAvailableSpacesException e) {}
	}

	private void assertMissingCar(ParkingLot lot, Object car) {
		try {
			lot.remove(car);
			fail("Did not expect to find car.");
		}
		catch (CarNotFoundException e) {}
	}

	private void assertNotified(ParkingSpaces attendant) {
		try {
			assertFalse(attendant.canPark());
			attendant.park(car());
			fail("Should not be able to park car.");
		}
		catch (NoAvailableSpacesException e) {}
	}

	private void assertNext(ParkingSpaces attendant, ParkingLot ... lots) {
		for (ParkingLot lot : lots)
			assertNext(attendant, lot);
	}

	private void assertNext(ParkingSpaces attendant, ParkingLot lot) {
		new Attendant(lot) {
			public void notify(int cars, int capacity, ParkingLot lot) {
				observedLot = lot;
			}
		};
		
		observedLot = null;
		Object car = car();
		attendant.park(car);
		assertEquals(lot, observedLot);
	}

}
