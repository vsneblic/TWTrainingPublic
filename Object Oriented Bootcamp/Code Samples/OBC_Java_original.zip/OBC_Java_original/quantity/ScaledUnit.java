package quantity;


/**
 * 	Understands a specific metric along a scale.
 */
public class ScaledUnit extends Unit {
	private static final Object TEMPERATURE = new Object();
	static final ScaledUnit C = new ScaledUnit(0, 1.8, TEMPERATURE);
	static final ScaledUnit F = new ScaledUnit(32, 1.0, TEMPERATURE);

	final int offset;

	private ScaledUnit(int offset, double ratio, Object type) {
		super(ratio, type);
		this.offset = offset;
	}

	public Quantity degrees(int amount) {
		return new Quantity(this, amount);
	}

	double amountIn(double amount, Unit base) {
		return amountIn(amount, (ScaledUnit)base);
	}

	double amountIn(double amount, ScaledUnit base) {
		return (amount-offset)*ratio/base.ratio + base.offset;
	}
}