﻿
namespace QuantityLength2
{
    public enum UnitOfLength
    {
        Feet,
        Inch,
        Yard,
        Mile
    }
}
