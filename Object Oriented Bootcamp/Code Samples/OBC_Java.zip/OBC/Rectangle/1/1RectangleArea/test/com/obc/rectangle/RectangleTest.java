package com.obc.rectangle;

import src.Rectangle;
import junit.framework.TestCase;

// Ensures correctness of Rectangle
public class RectangleTest extends TestCase {
	
	public void testArea() throws Exception {
		assertEquals(1, new Rectangle(1,1).area());
		assertEquals(15, new Rectangle(3,5).area());
	}
	

}
