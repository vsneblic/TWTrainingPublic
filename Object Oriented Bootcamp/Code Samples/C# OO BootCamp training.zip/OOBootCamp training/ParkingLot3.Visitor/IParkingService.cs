﻿namespace ParkingLot3.Visitor
{
    public interface IParkingService
    {
        double PercentageFull { get; }
        void ParkCar(Car carToPark);
        void ParkingServicesTour(IParkingServicesTourReporter visitor);
    }
}