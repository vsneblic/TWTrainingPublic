package com.obc.rectangle;

// Understands a 4 sided polygon with adjacent sides at right angles to each other
public class Rectangle {

	private final int length;

	private final int breadth;

	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	public int area() {
		return length * breadth;
	}

	public int perimeter() {
		return 2*(length+breadth);
	}
	
	public static Rectangle CreateSquare(int side) {
		return new Rectangle(side, side);
	}

}
