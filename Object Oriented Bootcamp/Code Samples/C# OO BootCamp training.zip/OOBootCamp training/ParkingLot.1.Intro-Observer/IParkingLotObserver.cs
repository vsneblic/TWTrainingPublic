﻿namespace ParkingLot1.Intro_Observer
{
    public interface IParkingLotObserver
    {
        void ChangeNotification(ParkingLot sender);
    }
}