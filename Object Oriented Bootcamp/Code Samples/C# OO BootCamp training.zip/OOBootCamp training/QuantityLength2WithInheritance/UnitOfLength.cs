﻿
namespace QuantityLength2WithInheritance
{
    public enum UnitOfLength
    {
        Feet,
        Inch,
        Yard,
        Mile
    }
}
