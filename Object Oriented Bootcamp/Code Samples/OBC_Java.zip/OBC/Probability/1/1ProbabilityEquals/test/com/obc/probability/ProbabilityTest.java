package com.obc.probability;

import src.Probability;
import junit.framework.TestCase;

// Ensures correctness of Probability
public class ProbabilityTest extends TestCase {

	private Probability probability1;

	public void testEquals() throws Exception {
		probability1 = new Probability(1.0);
		assertEquals(probability1, probability1);
		assertFalse(probability1.equals(new Probability(0.5)));
		assertFalse(probability1.equals(null));
		assertFalse(probability1.equals(new Object()));
	}
}
