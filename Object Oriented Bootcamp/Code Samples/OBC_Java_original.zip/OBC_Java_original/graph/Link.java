package graph;

/**
 * Understands a weighted connection to a Node.
 */
import java.util.List;
import java.util.Set;
public class Link {

	private final Node endPoint;
	private final int cost;

	Link(Node target, int cost) {
		this.endPoint = target;
		this.cost = cost;
	}

	static int cost(List<Link> links) {
		int cost = 0;
		for (Link link : links)
			cost += link.cost;
		return cost;
	}

	Paths paths(Node target, Set<Node> visited) {
		Paths paths = endPoint.paths(target, visited);
		if (paths != null)
			paths.prepend(this);
		return paths;
	}
}
