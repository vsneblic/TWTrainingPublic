package quantity;

/**
 * 	Understands communication of operating on incompatible Units.
 */
public class UnitMismatchException extends RuntimeException {

	private static final long serialVersionUID = 3252149290320157657L;

	public UnitMismatchException(Unit u1, Unit u2) {
		super("Operation can not be performed on a unit of type " + u1 + " and a unit of type " + u2);
	}
}
