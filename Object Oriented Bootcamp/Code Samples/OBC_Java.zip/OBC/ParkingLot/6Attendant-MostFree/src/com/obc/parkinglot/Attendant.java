package com.obc.parkinglot;

import java.util.ArrayList;
import java.util.List;

// Understands a person responsible for parking lots
public class Attendant implements ParkingLotObserver {

	private List<ParkingLot> allLots = new ArrayList<ParkingLot>();
	private List<ParkingLot> availableLots = new ArrayList<ParkingLot>();
	private final boolean parkToMostFree;

	public Attendant(boolean parkToMostFree) {
		this.parkToMostFree = parkToMostFree;
	}

	public Attendant() {
		this(false);
	}

	public void responsibleFor(ParkingLot lot) {
		allLots.add(lot);
		lot.addObserver(this);
		if (!lot.isFull())
			availableLots.add(lot);
	}

	public Object direct(Object car) throws CannotParkException {
		if (availableLots.isEmpty())
			throw CannotParkException.becauseAllLotsAreFull(car, this);
		if (parkToMostFree) {
			return mostFreeLot().park(car);
		}
		return firstAvailableLot().park(car);
	}

	private ParkingLot mostFreeLot() {
		ParkingLot champion = firstAvailableLot();
		for (ParkingLot challenger : availableLots) {
			if (challenger.freeSpace() > champion.freeSpace())
				champion = challenger;
		}
		return champion;
	}

	private ParkingLot firstAvailableLot() {
		return availableLots.get(0);
	}

	public Object unpark(Object token) throws CannotUnparkException {
		for (ParkingLot lot : allLots) {
			if (lot.hasCarFor(token))
				return lot.unpark(token);
		}
		throw new CannotUnparkException(token, this);
	}

	public void notifyFull(ParkingLot lot) {
		availableLots.remove(lot);
	}

	public void notifyHasSpace(ParkingLot lot) {
		availableLots.add(lot);
	}
}
