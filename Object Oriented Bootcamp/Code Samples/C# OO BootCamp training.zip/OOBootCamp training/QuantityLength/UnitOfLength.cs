﻿
namespace QuantityLength
{
    public enum UnitOfLength
    {
        Feet,
        Inch
    }
}
