package com.obc.parkinglot;

import java.util.ArrayList;
import java.util.List;

// Understands a collection of places which can hold cars
public class ParkingComplex extends ParkingSpace implements ParkingSpaceObserver {

	private List<ParkingSpace> allSpaces = new ArrayList<ParkingSpace>();
	private List<ParkingSpace> availableSpaces = new ArrayList<ParkingSpace>();
	private SpaceSelectionMethod lotSelectionMethod;

	public ParkingComplex(SpaceSelectionMethod spaceSelectionMethod) {
		this.lotSelectionMethod = spaceSelectionMethod;
	}

	public void responsibleFor(ParkingSpace lot) {
		allSpaces.add(lot);
		lot.addObserver(this);
		if (!lot.isFull())
			availableSpaces.add(lot);
	}

	public Object park(Object car, SpaceSelectionMethod lotSelectionMethod)
			throws CannotParkException {
		if (availableSpaces.isEmpty())
			throw CannotParkException.becauseAllLotsAreFull(car, this);
		return lotSelectionMethod.selectLotToParkInto(availableSpaces).park(car);
	}

	@Override
	protected Object doUnpark(Object token) throws CannotUnparkException {
		for (ParkingSpace space : allSpaces) {
			if (space.hasCarFor(token)) {
				return space.unpark(token);
			}
		}
		throw new CannotUnparkException(token, this);
	}

	public void notifyFull(ParkingSpace space) {
		availableSpaces.remove(space);
	}

	public void notifyHasSpace(ParkingSpace space) {
		availableSpaces.add(space);
	}

	@Override
	public int cost() {
		int answer = Integer.MAX_VALUE;
		for (ParkingSpace lot : availableSpaces) {
			if (lot.cost() < answer)
				answer = lot.cost();
		}
		return answer;
	}

	public int capacity() {
		int answer = 0;
		for (ParkingSpace space : availableSpaces) {
			if (space.capacity() > answer)
				answer = space.capacity();
		}
		return answer;
	}

	public int freeSpace() {
		int answer = 0;
		for (ParkingSpace space : availableSpaces) {
			if (space.freeSpace() > answer)
				answer = space.freeSpace();
		}
		return answer;
	}

	public boolean hasCarFor(Object token) {
		for (ParkingSpace space : allSpaces) {
			if (space.hasCarFor(token)) return true;
		}
		return false;
	}

	public boolean isFull() {
		for (ParkingSpace space : allSpaces) {
			if (!space.isFull()) return false;
		}
		return true;
	}

	public boolean hasCar(Object car) {
		for (ParkingSpace space : allSpaces) {
			if (space.hasCar(car)) return true;
		}
		return false;
	}

	protected Object doPark(Object car) throws CannotParkException {
		return park(car, lotSelectionMethod);
	}

	public static ParkingComplex firstLotParker() {
		return new ParkingComplex(SpaceSelectionMethod.FIRST_AVAILABLE);
	}

	public static ParkingComplex mostFreeLotParker() {
		return new ParkingComplex(SpaceSelectionMethod.MOST_FREE);
	}

	public static ParkingComplex mostCapacityLotParker() {
		return new ParkingComplex(SpaceSelectionMethod.MOST_CAPACITY);
	}
}
