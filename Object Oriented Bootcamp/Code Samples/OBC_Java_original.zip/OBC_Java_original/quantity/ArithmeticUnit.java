package quantity;

/**
 * 	Understands a specific metric that supports arithemetic priciples.
 */
public class ArithmeticUnit extends Unit {
	
	private static final Object LIQUID = new Object();
	static final ArithmeticUnit TSP = new ArithmeticUnit(1, LIQUID);
	static final ArithmeticUnit TBSP = new ArithmeticUnit(3, LIQUID);
	static final ArithmeticUnit OZ = new ArithmeticUnit(6, LIQUID);

	private static final Object DISTANCE = new Object();
	static final ArithmeticUnit FOOT = new ArithmeticUnit(1, DISTANCE);
	static final ArithmeticUnit YARD = new ArithmeticUnit(3, DISTANCE);
	static final ArithmeticUnit MILE = new ArithmeticUnit(5280, DISTANCE);
	
	private ArithmeticUnit(int amount, Object type) {
		super(amount, type);
	}

	public ArithmeticQuantity s(int amount) {
		return new ArithmeticQuantity(this, amount);
	}

	public ArithmeticQuantity es(int amount) {
		return this.s(amount);
	}
	
	double amountIn(double amount, Unit base) {
		return amount*ratio/base.ratio;
	}
}
