package com.obc.length;

// Understands a measurement of distance
public class Length {

	private final int value;
	private final Unit unit;

	public static Length yard(int numberOfYards) {
		return new Length(numberOfYards, Unit.YARD);
	}

	public static Length foot(int numberOfFeet) {
		return new Length(numberOfFeet, Unit.FOOT);
	}

	public static Length inch(int numberOfInches) {
		return new Length(numberOfInches, Unit.INCH);
	}

	private Length(int value, Unit unit) {
		this.value = value;
		this.unit = unit;
	}

	public String toString() {
		return "Length: " + value;
	}

	public boolean equals(Object other) {
		if ((other == null) || other.getClass() != getClass())
			return false;
		return inInches() == ((Length) other).inInches();
	}

	private int inInches() {
		return unit.inInches(value);
	}
}


// Understands a standard length
class Unit {

	private static final int INCHES_IN_YARD = 36;
	private static final int INCHES_IN_FOOT = 12;

	public static final Unit INCH = new Unit(1);
	public static final Unit YARD = new Unit(INCHES_IN_YARD);
	public static final Unit FOOT = new Unit(INCHES_IN_FOOT);

	private final int numberOfInches;
	
	private Unit(int numberOfInches) {
		this.numberOfInches = numberOfInches;
	}

	public int inInches(int value) {
		return value*numberOfInches;
	}
}