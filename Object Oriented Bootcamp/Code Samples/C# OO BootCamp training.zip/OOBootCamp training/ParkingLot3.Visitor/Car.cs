﻿namespace ParkingLot3.Visitor
{
    public class Car {}
}