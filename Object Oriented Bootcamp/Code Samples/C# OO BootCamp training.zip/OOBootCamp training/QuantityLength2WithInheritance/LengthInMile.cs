﻿namespace QuantityLength2WithInheritance
{
    public class LengthInMile : Length
    {
        private const double ConversionFactorToInches =  36.0 * 1760.0;

        public LengthInMile(double value) : base(value, ConversionFactorToInches) {}

        public static LengthInMile operator +(LengthInMile leftValue, LengthInMile rightValue)
        {
            return new LengthInMile(leftValue.SumUpWithTheValueOf(rightValue));
        }
    }
}