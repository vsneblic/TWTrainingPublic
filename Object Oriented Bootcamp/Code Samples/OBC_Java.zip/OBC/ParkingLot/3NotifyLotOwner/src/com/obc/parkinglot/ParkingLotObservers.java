package com.obc.parkinglot;

import java.util.ArrayList;

public class ParkingLotObservers extends ArrayList<ParkingLotObserver> {

	public void notifyHasSpace() {
		for (ParkingLotObserver observer : this) {
			observer.notifyHasSpace();
		}
	}

	public void notifyFull() {
		for (ParkingLotObserver observer : this) {
			observer.notifyFull();
		}
	}
	
}
