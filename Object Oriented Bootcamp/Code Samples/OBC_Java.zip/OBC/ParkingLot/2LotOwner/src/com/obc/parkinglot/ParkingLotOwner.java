package com.obc.parkinglot;


interface ParkingLotOwner {

	public abstract void notifyFull();

}