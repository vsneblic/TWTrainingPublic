package com.obc.quantity;

import src.IncompatibleUnitsException;
import src.Quantity;
import junit.framework.TestCase;

// Ensures correctness of Quantity
public class QuantityTest extends TestCase {

	private Quantity foot1;
	private Quantity inch12;
	private Quantity gram1;

	protected void setUp() {
		foot1 = Quantity.foot(1);
		inch12 = Quantity.inch(12);
		gram1 = Quantity.gram(1);
	}

	public void testSameUnitEquals() {
		assertEquals(foot1, Quantity.foot(1));
		assertFalse(foot1.equals(Quantity.foot(2)));
		assertFalse(foot1.equals(null));
		assertFalse(foot1.equals(new Object()));
	}

	public void testDifferentUnitEquals() {
		assertFalse(foot1.equals(Quantity.inch(1)));
		assertEquals(foot1, inch12);
		assertEquals(inch12, foot1);
	}
	
	public void testYardEquals() {
		assertEquals(Quantity.foot(3), Quantity.yard(1));
	}
	
	public void testWeightEquals() {
		assertEquals(gram1, Quantity.gram(1));
		final Quantity kg1 = Quantity.kilogram(1);
		assertEquals(kg1, Quantity.kilogram(1));
		assertEquals(kg1, Quantity.gram(1000));
	}
	
	public void testWeightNotEqualsLength() {
		assertFalse(Quantity.gram(1).equals(Quantity.inch(1)));
	}
	
	public void testAdd() throws IncompatibleUnitsException  {
		final Quantity foot2 = Quantity.foot(2);
		assertEquals(foot2, foot1.add(foot1));
		assertEquals(foot2, foot1.add(inch12));
		assertEquals(Quantity.kilogram(2), Quantity.gram(1000).add(Quantity.kilogram(1)));
	}
	
	public void testCannotAddALengthAndAWeight() {
		try {
			foot1.add(gram1);
			fail("Shouldn't be able to add a gram and a foot");
		} catch (IncompatibleUnitsException expected) {
		}
	}
	
	public void testCanHandleFractionalValues() {
		assertEquals(Quantity.foot(0.5), Quantity.inch(6));
		assertEquals(Quantity.yard(1.0/3.0), foot1);
		assertEquals(Quantity.inch(0.5), Quantity.inch(0.5));
		assertEquals(Quantity.gram(500), Quantity.kilogram(0.5));
		assertEquals(Quantity.gram(0.5), Quantity.gram(0.5));
	}
	
	public void testTemperatureEquals() {
		assertEquals(Quantity.celsius(0), Quantity.celsius(0));
		assertFalse(Quantity.celsius(0).equals(Quantity.celsius(1)));
		assertEquals(Quantity.kelvin(273), Quantity.celsius(0));
		assertEquals(Quantity.fahrenheit(-40), Quantity.celsius(-40));
	}
}
