﻿using NUnit.Framework;

namespace ParkingLot2.Composite.Tests
{
    [TestFixture]
    public class AttendantWithCousinAndEmployeesFillLotTest
    {
        private Attendant _attendant;
        private Attendant _cousin;
        private Attendant _employee;
        private Attendant _uncle;

        private ParkingLot _emptyParkingLot;
        private ParkingLot[] _parkingLot;

        private Car _car;

        [SetUp]
        public void SetUp()
        {
            _car = new Car();

            _attendant = new Attendant();
            _cousin = new Attendant();
            _employee = new Attendant();
            _uncle = new Attendant();

            _attendant.Attend(_cousin);
            _attendant.Attend(_uncle);
            _cousin.Attend(_employee);

            _emptyParkingLot = new ParkingLot(capacity: 10);

            _parkingLot = new ParkingLot[8];
            for (int i = 0; i < 8; i++)
            {
                _parkingLot[i] = new ParkingLot(capacity: 10);
                _parkingLot[i].ParkCar(new Car());
            }

            _attendant.Attend(_parkingLot[0]);
            _attendant.Attend(_parkingLot[1]);

            _cousin.Attend(_parkingLot[2]);
            _cousin.Attend(_parkingLot[3]);

            _employee.Attend(_parkingLot[4]);
            _employee.Attend(_parkingLot[5]);

            _uncle.Attend(_parkingLot[6]);
            _uncle.Attend(_parkingLot[7]);
        }

        [Test]
        public void When_parking_a_car_the_empty_parking_lot_of_the_attendant_should_be_selected()
        {
            _attendant.Attend(_emptyParkingLot);

            _attendant.ParkCar(_car);

            Assert.That(_emptyParkingLot.PercentageFull > 0.0);
        }

        [Test]
        public void When_parking_a_car_the_empty_parking_lot_of_the_cousin_should_be_selected()
        {
            _cousin.Attend(_emptyParkingLot);

            _cousin.ParkCar(_car);

            Assert.That(_emptyParkingLot.PercentageFull > 0.0);
        }

        [Test]
        public void When_parking_a_car_the_empty_parking_lot_of_the_employee_should_be_selected()
        {
            _employee.Attend(_emptyParkingLot);

            _employee.ParkCar(_car);

            Assert.That(_emptyParkingLot.PercentageFull > 0.0);
        }

        [Test]
        public void When_parking_a_car_the_empty_parking_lot_of_the_uncle_should_be_selected()
        {
            _uncle.Attend(_emptyParkingLot);

            _uncle.ParkCar(_car);

            Assert.That(_emptyParkingLot.PercentageFull > 0.0);
        }

    }
}
