package quantity;

/**
 * Ensures the correctness of Quantity.
 */
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static quantity.ArithmeticUnit.FOOT;
import static quantity.ArithmeticUnit.MILE;
import static quantity.ArithmeticUnit.OZ;
import static quantity.ArithmeticUnit.TBSP;
import static quantity.ArithmeticUnit.TSP;
import static quantity.ArithmeticUnit.YARD;
import static quantity.ScaledUnit.C;
import static quantity.ScaledUnit.F;

import org.junit.Test;

public class QuantityTest {

	@Test
	public void shouldBeAbleToCompareLiquidMeasures() {
		assertEquals(TSP.s(6), TSP.s(6));
		assertEquals(TBSP.s(2), TBSP.s(2));
		assertNotEquals(TSP.s(6), TBSP.s(6));
		assertEquals(TSP.s(6), TBSP.s(2));
		assertEquals(TBSP.s(2), TSP.s(6));
		assertEquals(OZ.es(2), TBSP.s(4));
		assertEquals(TBSP.es(4), OZ.es(2));
	}
	
	@Test
	public void shouldBeAbleToCompareDistances() {
		assertEquals(FOOT.s(2), FOOT.s(2));
		assertEquals(YARD.s(3), YARD.s(3));
		assertNotEquals(FOOT.s(6), YARD.s(6));
		assertEquals(FOOT.s(6), YARD.s(2));
		assertEquals(YARD.s(2), FOOT.s(6));
		assertEquals(MILE.es(2), YARD.s(3520));
		assertEquals(YARD.s(3520), MILE.s(2));
	}

	@Test
	public void shouldNotBeAbleToCompareLiquidsAndDistances() {
		assertNotEquals(TSP.s(2), FOOT.s(2));
	}
	
	@Test
	public void shouldBeAbleToAddSimilarMeasures() {
		assertEquals(TSP.s(4), TSP.s(2).add(TSP.s(2)));
		assertEquals(TSP.s(12), TSP.s(6).add(TBSP.s(2)));
		assertEquals(TBSP.s(4), TBSP.s(2).add(TSP.s(6)));
	}
	
	@Test(expected=UnitMismatchException.class)
	public void shouldNotBeAbleToAddDissimilarMeasures() {
		TSP.s(3).add(YARD.s(6));
	}
	
	@Test
	public void shouldBeAbleToCompareTemperatures() {
		assertEquals(C.degrees(100), C.degrees(100));
		assertEquals(F.degrees(212), F.degrees(212));
		assertEquals(C.degrees(100), F.degrees(212));
		assertEquals(F.degrees(212), C.degrees(100));
		assertEquals(C.degrees(0), F.degrees(32));
		assertEquals(F.degrees(32), C.degrees(0));
		assertEquals(C.degrees(-40), F.degrees(-40));
		assertEquals(F.degrees(-40), C.degrees(-40));
	}
	
//	@Test
//	public void shouldNotBeAbleToCallIllegalOperations() {
//		C.degrees(0).add(F.degrees(32));
//		C.s(100);
//		TSP.degrees(2);
//	}
	
	private void assertNotEquals(Quantity expected, ArithmeticQuantity actual) {
		assertFalse(actual.equals(expected));
	}
}
