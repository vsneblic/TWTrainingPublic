﻿namespace QuantityLength2WithInheritance
{
    public class LengthInFeet : Length
    {
        private const double ConversionFactorToInches = 12.0;

        public LengthInFeet(double value) : base(value, ConversionFactorToInches) {}

        public static LengthInFeet operator +(LengthInFeet leftValue, LengthInFeet rightValue)
        {
            return new LengthInFeet(leftValue.SumUpWithTheValueOf(rightValue));
        }
    }
}