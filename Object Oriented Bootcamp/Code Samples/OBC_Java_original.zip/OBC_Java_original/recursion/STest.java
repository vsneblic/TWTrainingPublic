package recursion;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * 	Ensures the correctness of S.
 */
public class STest {
	private static final S A = new S("A");
	private static final S AB = new S("AB");
	private static final S ABC = new S("ABC");
	private static final S BA = new S("BA");
	private static final S CBA = new S("CBA");

	@Test
	public void shouldBeAbleToReverseMyself() {
		assertEquals(A, A.reverse());
		assertEquals(BA, AB.reverse());
		assertEquals(CBA, ABC.reverse());
	}
}
