module Bootcamp
  module Probability
  
    # Understands the likelihood of something occurring.
    class Chance
      CERTAIN_VALUE = 1.0
      
      attr_reader :value
      protected :value
      
      def initialize(value_as_fraction)
        @value = value_as_fraction
      end
      
      def ==(other)
        @value == other.value 
      end
      
      def not
        Chance.new(CERTAIN_VALUE - @value)
      end
      
      def and(other)
        Chance.new(other.value * @value)
      end
      
      def or(other) 
        self.not.and(other.not).not
      end
      
      def to_s
        (@value * 100) + '%'
      end
    
    end
  end
end