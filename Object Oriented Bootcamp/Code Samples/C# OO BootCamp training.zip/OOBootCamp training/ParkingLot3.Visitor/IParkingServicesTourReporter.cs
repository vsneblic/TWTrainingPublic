﻿using System.Collections.Generic;

namespace ParkingLot3.Visitor
{
    public interface IParkingServicesTourReporter
    {
        void CollectInformation(Attendant attendant, List<IParkingService> parkingServices);
        void CollectInformation(ParkingLot parkingLot, int capacity, int parkedCarsCount);
    }
}