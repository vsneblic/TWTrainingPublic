﻿using System;
using NUnit.Framework;

namespace QuantityLength2.Tests
{
    [TestFixture]
    public class LengthAddTest
    {
        [Test]
        public void Adding_two_different_units_of_lenght_should_raise_an_exception()
        {
            Assert.Throws<ArgumentException>(() => { var result = new Length(UnitOfLength.Inch, 10) + new Length(UnitOfLength.Feet, 1); });
        }

        [Test]
        public void Adding_two_lengths_of_the_same_unit_return_the_sum()
        {
            var result = new Length(UnitOfLength.Feet, 10) + new Length(UnitOfLength.Feet, 1);

            var expectedResult = new Length(UnitOfLength.Feet, 11);

            Assert.That(result.IsEquivalentTo(expectedResult), Is.True);
        }
    }
}
