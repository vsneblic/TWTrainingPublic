package com.obc.parkinglot;

import java.util.ArrayList;
import java.util.List;

public class EventCoordinator {

	private List<ParkingComplex> attendants = new ArrayList<ParkingComplex>();
	private List<ParkingLot> lots = new ArrayList<ParkingLot>();

	public void add(ParkingComplex attendant) {
		attendants.add(attendant);		
	}

	public Object direct(Object car) throws CannotParkException {
		for (ParkingComplex attendant : attendants) {
			try {
				return attendant.park(car);
			} catch (CannotParkException e) {
			}
		}
		for (ParkingSpace lot : lots) {
			if (!lot.isFull()) return lot.park(car);
		}
		throw CannotParkException.becauseAllLotsAreFull(car, this);
	}

	public void add(ParkingLot lot) {
		lots.add(lot);		
	}

}
