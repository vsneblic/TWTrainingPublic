package parking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;


/**
 * 	Understands regulating access to a ParkingLot.
 */
public class Attendant extends ParkingSpaces implements ParkingLotObserver {

	private static final double THRESHOLD = .8;
	private Collection<ParkingSpaces> allSpaces = new ArrayList<ParkingSpaces>();
	private List<ParkingSpaces> availableSpaces = new ArrayList<ParkingSpaces>();

	public Attendant(ParkingSpaces ...attendedSpaces) {
		this("Attendant", attendedSpaces);
	}
	
	public Attendant(String name, ParkingSpaces ...attendedSpaces) {
		super(name);
		this.allSpaces.addAll(Arrays.asList(attendedSpaces));
		this.availableSpaces.addAll(Arrays.asList(attendedSpaces));
		for (ParkingSpaces spaces : allSpaces)
			spaces.addObserver(this);
	}

	public boolean canPark() {
		for (ParkingSpaces spaces : availableSpaces)
			if (spaces.canPark()) return true;
		return false;
	}

	public void park(Object car) {
		if (!canPark()) throw new NoAvailableSpacesException();
		Collections.min(availableSpaces, LEAST_FULL).park(car);
	}

	public void remove(Object car) {
		for (ParkingSpaces spaces : allSpaces)
			if (remove(car, spaces)) return;
		throw new CarNotFoundException(car);
	}

	public void notify(int cars, int capacity, ParkingLot lot) {
		if (!availableSpaces.contains(lot))
			availableSpaces.add(lot);
		if ((double)cars/capacity >= THRESHOLD)
			availableSpaces.remove(lot);
	}

	boolean contains(Object car) {
		for (ParkingSpaces space : allSpaces)
			if (space.contains(car)) return true;
		return false;
	}
	
	int percentFull() {
		return bestLot().percentFull();
	}

	private boolean remove(Object car, ParkingSpaces lot) {
		if (lot.contains(car)) {
			lot.remove(car);
			return true;
		}
		return false;
	}

	private ParkingSpaces bestLot() {
		if (availableSpaces.isEmpty()) return NO_AVAILABLE_SPACES;
		return Collections.min(availableSpaces, LEAST_FULL);
	}

	void accept(ParkingLotVisitor visitor) {
		visitor.previsit(this);
		visitor.visit(this);
		for (ParkingSpaces spaces : allSpaces)
			spaces.accept(visitor);
		visitor.postvisit(this);
	}
	
	int carCount() {
		return 0;
	}
}
