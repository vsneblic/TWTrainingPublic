﻿using System.Collections.Generic;

namespace ParkingLot3.Visitor
{
    public class ParkingLotsAndAttendantsReporter : IParkingServicesTourReporter
    {
        private readonly Dictionary<ParkingLot, string> _visitedParkingLot = new Dictionary<ParkingLot, string>();
        private readonly Dictionary<Attendant, string> _visitedAttendant = new Dictionary<Attendant, string>();
        private string _report = "";

        public void CollectInformation(Attendant attendant, List<IParkingService> parkingServices)
        {
            if (_visitedAttendant.ContainsKey(attendant))
            {
                return;
            }

            BeginAttendantReport(attendant);

            VisitNestedAttendantsParkingServices(parkingServices);

            EndAttendantReport();
            
        }

        public void CollectInformation(ParkingLot parkingLot, int capacity, int parkedCarsCount)
        {
            ReportAboutParkingLot(parkingLot, capacity);
        }

        private void ReportAboutParkingLot(ParkingLot parkingLot, int capacity)
        {
            if (_visitedParkingLot.ContainsKey(parkingLot))
            {
                return;
            }

            _visitedParkingLot[parkingLot] = ((char) ('A' + _visitedParkingLot.Count)).ToString();
            _report += (string.Format("Parking Lot {0}: capacity {1}; ", _visitedParkingLot[parkingLot], capacity));
        }

        private void BeginAttendantReport(Attendant attendant)
        {
            _visitedAttendant[attendant] = _visitedAttendant.Count.ToString();
            _report += (string.Format("Attendant {0} {1} ", _visitedAttendant[attendant], "{"));
        }

        private void VisitNestedAttendantsParkingServices(List<IParkingService> parkingServices)
        {
            parkingServices.ForEach(p => p.ParkingServicesTour(this));
        }

        private void EndAttendantReport()
        {
            _report += "} ";
        }

        public string Report
        {
            get { return _report; }
        }
    }
}