﻿using System.Collections.Generic;

namespace ParkingLot3.Visitor
{
    public class ParkingServiceFullnessComparer : Comparer<IParkingService>
    {
        public override int Compare(IParkingService left, IParkingService right)
        {
            if (left == right)
            {
                return 0;
            }

            if (left == null)
            {
                return -1;
            }

            if (right == null)
            {
                return +1;
            }

            return left.PercentageFull.CompareTo(right.PercentageFull);
        }
    }
}