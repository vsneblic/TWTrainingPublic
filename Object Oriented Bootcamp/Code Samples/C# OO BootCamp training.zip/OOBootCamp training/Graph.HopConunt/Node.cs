﻿

using System.Collections.Generic;
using System.Linq;

namespace Graph.HopCount
{
    public class Node
    {
        private readonly string _name;
        private readonly List<Node> _neightbors;

        public Node(string name) : this(name, new Node[0])
        {
        }

        public Node(string name, IEnumerable<Node> neightbors)
        {
            _name = name;
            _neightbors = new List<Node>(neightbors);
        }

        public void AddNeighbor(Node neighborNode)
        {
            _neightbors.Add(neighborNode);
        }


        public bool CanReach(Node destination)
        {
            return HopCountTo(destination) >= 0;
        }

        public int HopCountTo(Node destination)
        {
            return HopCountTo(destination, new List<Node>());
        }

        private int HopCountTo(Node destination, ICollection<Node> visitedNodes)
        {
            if (this == destination)
            {
                return 0;
            }

            visitedNodes.Add(this);

            const int hopCountForDestinationNotFound = -1;
            foreach (var neighbor in _neightbors.Except(visitedNodes))
            {
                var hopCountFromHere = neighbor.HopCountTo(destination, visitedNodes);
                if (hopCountFromHere != hopCountForDestinationNotFound)
                {
                    return 1 + hopCountFromHere;
                }
            }

            return hopCountForDestinationNotFound;
        }
    }
}
