package com.obc.quantity;


// Understands a measurement
public class Quantity {

	private final int value;
	private final Unit unit;

	public static Quantity Yard(int numberOfYards) {
		return new Quantity(numberOfYards, Unit.YARD);
	}

	public static Quantity Foot(int numberOfFeet) {
		return new Quantity(numberOfFeet, Unit.FOOT);
	}

	public static Quantity Inch(int numberOfInches) {
		return new Quantity(numberOfInches, Unit.INCH);
	}

	public static Quantity Gram(int numberOfGrams) {
		return new Quantity(numberOfGrams, Unit.GRAM);
	}

	public static Quantity Kg(int numberOfKilos) {
		return new Quantity(numberOfKilos, Unit.KG);
	}

	private Quantity(int value, Unit unit) {
		this.value = value;
		this.unit = unit;
	}

	public String toString() {
		return "" + value + " " + unit;
	}

	public boolean equals(Object other) {
		if ((other == null) || other.getClass() != getClass())
			return false;
		final Quantity otherQuantity = ((Quantity) other);
		if (!unit.comparableWith(otherQuantity.unit)) return false;
		return value == otherQuantity.convertTo(unit);
	}

	public Quantity add(Quantity other) throws IncompatibleUnitsException {
		if (!unit.comparableWith(other.unit))
			throw new IncompatibleUnitsException("Can't add units of different kinds: " + unit + " and " + other.unit);
		return new Quantity(value + other.convertTo(unit), unit);
	}

	private int convertTo(Unit toUnit) {
		return unit.convertTo(value, toUnit);
	}
}

// Understands a metric
class Unit {

	private static final Object WEIGHT = new Object();
	private static final Object LENGTH = new Object();

	private static final int GRAMS_IN_KILOS = 1000;
	public static final Unit GRAM = new Unit(1, WEIGHT, "g");
	public static final Unit KG = new Unit(GRAMS_IN_KILOS, WEIGHT, "Kg");

	private static final int INCHES_IN_YARD = 36;
	private static final int INCHES_IN_FOOT = 12;

	public static final Unit INCH = new Unit(1, LENGTH, "in");
	public static final Unit YARD = new Unit(INCHES_IN_YARD, LENGTH, "yd");
	public static final Unit FOOT = new Unit(INCHES_IN_FOOT, LENGTH, "ft");

	private final int numberOfBaseUnits;
	private final Object unitType;
	private String name;

	private Unit(int numberOfBaseUnits, Object unitType, String name) {
		this.numberOfBaseUnits = numberOfBaseUnits;
		this.unitType = unitType;
		this.name = name;
	}

	public int convertTo(int value, Unit toUnit) {
		return value*numberOfBaseUnits/toUnit.numberOfBaseUnits;
	}

	public boolean comparableWith(Unit other) {
		return unitType == other.unitType;
	}

	public String toString() {
		return name;
	}


}