package com.obc.parkinglot;

import java.util.ArrayList;
import java.util.List;

// Understands a person responsible for parking lots
public class Attendant implements ParkingLotObserver {

	private List<ParkingLot> allLots = new ArrayList<ParkingLot>();
	private List<ParkingLot> availableLots = new ArrayList<ParkingLot>();
	private final LotToPark toPark;

	public Attendant() {
		this(LotToPark.FIRST_LOT);
	}

	public Attendant(LotToPark toPark) {
		this.toPark = toPark;
	}

	public void responsibleFor(ParkingLot lot) {
		allLots.add(lot);
		lot.addObserver(this);
		if (!lot.isFull())
			availableLots.add(lot);
	}

	public Object direct(Object car) throws CannotParkException {
		if (availableLots.isEmpty())
			throw CannotParkException.becauseAllLotsAreFull(car, this);
		if (toPark == LotToPark.MOST_CAPACITY)
			return mostCapacityLot().park(car);
		else if (toPark == LotToPark.MOST_FREE) {
			return mostFreeLot().park(car);
		} else 
			return firstAvailableLot().park(car);
	}

	private ParkingLot mostCapacityLot() {
		ParkingLot champion = availableLots.get(0);
		for (ParkingLot challenger : availableLots) {
			if (challenger.capacity() > champion.capacity())
				champion = challenger;
		}
		return champion;
	}

	private ParkingLot mostFreeLot() {
		ParkingLot champion = availableLots.get(0);
		for (ParkingLot challenger : availableLots) {
			if (challenger.freeSpace() > champion.freeSpace())
				champion = challenger;
		}
		return champion;
	}

	private ParkingLot firstAvailableLot() {
		return availableLots.get(0);
	}

	public Object unpark(Object token) throws CannotUnparkException {
		for (ParkingLot lot : allLots) {
			if (lot.hasCarFor(token))
				return lot.unpark(token);
		}
		throw new CannotUnparkException(token, this);
	}

	public void notifyFull(ParkingLot lot) {
		availableLots.remove(lot);
	}

	public void notifyHasSpace(ParkingLot lot) {
		availableLots.add(lot);
	}
}

enum LotToPark {
	FIRST_LOT,
	MOST_FREE,
	MOST_CAPACITY
}

