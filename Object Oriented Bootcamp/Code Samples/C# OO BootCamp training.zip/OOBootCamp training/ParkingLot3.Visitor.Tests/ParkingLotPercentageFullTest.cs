﻿using NUnit.Framework;

namespace ParkingLot3.Visitor.Tests
{
    [TestFixture]
    public class ParkingLotPercentageFullTest
    {
        private ParkingLot _parkingLot;

        [SetUp]
        public void SetUp()
        {
            _parkingLot = new ParkingLot(capacity: 6);        
        }

        [Test]
        public void When_empty_should_be_0perc_full()
        {
            Assert.That(_parkingLot.PercentageFull, Is.EqualTo(0.0));
        }

        [Test]
        public void When_full_should_be_100penc_full()
        {
            for (int i = 1; i <= 6; i++)
            {
                _parkingLot.ParkCar(new Car());
            }

            Assert.That(_parkingLot.PercentageFull, Is.EqualTo(100.0));
            
        }

        [Test]
        public void With_3_cars_parked_and_3_available_spaces_shoud_be_50perc_full()
        {
            _parkingLot.ParkCar(new Car());
            _parkingLot.ParkCar(new Car());
            _parkingLot.ParkCar(new Car());

            Assert.That(_parkingLot.PercentageFull, Is.EqualTo(50.0));
            
        }
    }

    class ParkingLotPercentageFullTestImpl : ParkingLotPercentageFullTest
    {
    }
}
