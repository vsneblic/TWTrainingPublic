package com.obc.parkinglot;

// understands the contract interested parties need to follow 
// to be notified of changes in ParkingLot 
interface ParkingLotObserver {

	public abstract void notifyFull(ParkingLot lot);

	public abstract void notifyHasSpace(ParkingLot lot);

}