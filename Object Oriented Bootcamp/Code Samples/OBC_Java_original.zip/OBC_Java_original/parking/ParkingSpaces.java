package parking;

import java.util.Comparator;

public abstract class ParkingSpaces {
	final String name;

	ParkingSpaces(String name) {
		this.name = name;
	}

	static final Comparator<ParkingSpaces> LEAST_FULL = new Comparator<ParkingSpaces>() {

		public int compare(ParkingSpaces left, ParkingSpaces right) {
			return left.percentFull() - right.percentFull();
		}
		
	};
	
	public abstract boolean canPark();

	public abstract void park(Object car);

	public abstract void remove(Object car);

	abstract int percentFull();

	abstract boolean contains(Object car);
	
	void addObserver(ParkingLotObserver observer) {}

	static ParkingLotVisitor carCountVisitor() {
		return new ParkingLotVisitor() {
			private int count;
			
			public String print() {
				return Integer.toString(count);
			}

			public void visit(ParkingSpaces spaces) {
				count += spaces.carCount();
			}

			public void previsit(Attendant attendant) {}
			public void postvisit(Attendant attendant) {}
			public void previsit(ParkingLot lot) {}
			public void postvisit(ParkingLot lot) {}
		};
	}
	
	static ParkingLotVisitor printVisitor() {
		return new ParkingLotVisitor() {
			private String structure = "";
			
			public String print() {
				return structure;
			}

			public void visit(ParkingSpaces spaces) {
				structure += spaces.name + " ";
			}

			public void previsit(Attendant attendant) {
				structure += "{ ";
			}

			public void postvisit(Attendant attendant) {
				structure += "} ";
			}

			public void previsit(ParkingLot lot) {}
			public void postvisit(ParkingLot lot) {}
		};
	}
	
	abstract void accept(ParkingLotVisitor visitor);
	
	abstract int carCount();

	public String printCarCount() {
		ParkingLotVisitor visitor = carCountVisitor();
		accept(visitor);
		return visitor.print();
	}
	
	public String printStructure() {
		ParkingLotVisitor visitor = printVisitor();
		accept(visitor);
		return visitor.print();
	}

	static final ParkingSpaces NO_AVAILABLE_SPACES = new ParkingSpaces("NONE") {

		public boolean canPark() {
			return false;
		}

		boolean contains(Object car) {
			return false;
		}

		public void park(Object car) {
		}

		int percentFull() {
			return 1000;
		}

		public void remove(Object car) {
		}

		public void accept(ParkingLotVisitor visitor) {
		}

		int carCount() {
			return 0;
		}
	};
	
}