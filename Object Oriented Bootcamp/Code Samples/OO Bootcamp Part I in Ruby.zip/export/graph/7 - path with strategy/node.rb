module Bootcamp
  module Graph
    
    # Understands its neighors
    class Node
    
      def initialize(name)
        @name = name
        @links = []
      end
      
      def connect_to(neighbor, cost=0)
        @links << Link.new(neighbor, cost)
      end
      
      def reach?(destination)
        _path(destination) != $NO_PATH
      end

      def hop_count(destination)
        path_with_strategy(destination, $HOP_COUNT).hop_count
      end

      def cost(destination)
        path(destination).cost
      end

      def path(destination)
        path_with_strategy(destination)
      end

      private
      def path_with_strategy(destination, strategy = $ACTUAL_COST)
        result = _path(destination, [], strategy)
        raise NoPathError.new(self, destination) if result == $NO_PATH
        result
      end
      
      public
      def _path(destination, visited_nodes = [], strategy = $ACTUAL_COST)
        return Path.new if self == destination
        return $NO_PATH if visited_nodes.include?(self)
        (visited_nodes = visited_nodes.dup) << self
        @links.inject($NO_PATH) do 
          |champion, link| 
          champion.lesser(link._path(destination, visited_nodes, strategy), strategy)
        end
      end
      
    end

  end
end