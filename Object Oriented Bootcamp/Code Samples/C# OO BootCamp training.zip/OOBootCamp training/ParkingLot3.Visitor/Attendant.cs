﻿using System;
using System.Collections.Generic;

namespace ParkingLot3.Visitor
{
    public class Attendant : IParkingService
    {
        private static readonly ParkingServiceFullnessComparer Comparer = new ParkingServiceFullnessComparer();

        private readonly List<IParkingService> _parkingServices;

        public Attendant()
        {
            _parkingServices = new List<IParkingService>();
        }

        public void Attend(IParkingService parkingLotOrAnotherAttendant)
        {
            _parkingServices.Add(parkingLotOrAnotherAttendant);
        }

        public double PercentageFull {
            get
            {
                if (_parkingServices.Count == 0)
                {
                    return 100.0;
                }

                Sort();
                return _parkingServices[0].PercentageFull;
            }
        }

        public void ParkCar(Car carToPark)
        {
            if (_parkingServices.Count == 0)
            {
                throw new InvalidOperationException("No parking lots attended by this attendant. Cannot park the car.");
            }

            Sort();
            _parkingServices[0].ParkCar(carToPark);
        }

        public void ParkingServicesTour(IParkingServicesTourReporter visitor)
        {
            visitor.CollectInformation(this, _parkingServices);
        }

        private void Sort()
        {
            _parkingServices.Sort(Comparer);            
        }
    }
}