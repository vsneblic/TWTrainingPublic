module Bootcamp
  module Quantity

    # Understands a specific metric
    class Unit
      
      attr_reader :base_amount, :offset, :metric_type
      protected :base_amount, :offset, :metric_type
      
      def initialize(metric_type, name, number_of_base_units, offset = 0)
        @name, @metric_type = name, metric_type
        @base_amount, @offset = number_of_base_units.to_f, offset
      end
      
      $TEMPERATURE = Object.new
      $CELCIUS = Unit.new($TEMPERATURE, "celcius", 1, 0)
      $FAHRENHEIT = Unit.new($TEMPERATURE, "fahrenheit", 5.0/9, 32)
            
      def amount(value) 
        Quantity.new(value, self)
      end
      
      def degrees(value)
        amount(value)
      end
      
      def amountFrom(other_amount, other_unit)
        (other_amount - other_unit.offset) * other_unit.base_amount / @base_amount + @offset 
      end
      
      def compatible?(other)
        @metric_type == other.metric_type
      end
      
    end
  end
end