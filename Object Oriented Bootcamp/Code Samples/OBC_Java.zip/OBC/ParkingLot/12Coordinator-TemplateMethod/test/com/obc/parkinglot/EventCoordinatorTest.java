package com.obc.parkinglot;

import junit.framework.TestCase;

// Ensures correctness of the event coordinator
public class EventCoordinatorTest extends TestCase {
	
	public void testCoordinatorCanDirectCarsTo1Attendant() throws Exception {
		ParkingComplex attendant = ParkingComplex.firstLotParker();
		ParkingSpace lot = new ParkingLot(1);
		attendant.responsibleFor(lot);
		

		ParkingComplex coordinator = ParkingComplex.firstLotParker();
		coordinator.responsibleFor(attendant);

		Object token = coordinator.park(car());
		assertTrue(lot.hasCarFor(token));
	}
	
	public void testCoordinatorCanDirectCarsTo2ndAttendant() throws Exception {
		ParkingComplex coordinator = ParkingComplex.firstLotParker();

		ParkingSpace lot1 = new ParkingLot(1);
		lot1.park(car());
		ParkingComplex attendant1 = ParkingComplex.firstLotParker();
		attendant1.responsibleFor(lot1);
		coordinator.responsibleFor(attendant1);

		ParkingSpace lot2 = new ParkingLot(1);
		ParkingComplex attendant2 = ParkingComplex.firstLotParker();
		attendant2.responsibleFor(lot2);
		coordinator.responsibleFor(attendant2);
		
		Object token = coordinator.park(car());
		assertTrue(lot2.hasCarFor(token));
	}
	
	public void testCoordinatorWith2AttendantsCanDirectCarsTo1stAttendant() throws Exception {
		ParkingComplex coordinator = ParkingComplex.firstLotParker();

		ParkingSpace lot1 = new ParkingLot(1);
		ParkingComplex attendant1 = ParkingComplex.firstLotParker();
		attendant1.responsibleFor(lot1);
		coordinator.responsibleFor(attendant1);

		ParkingSpace lot2 = new ParkingLot(1);
		ParkingComplex attendant2 = ParkingComplex.firstLotParker();
		attendant2.responsibleFor(lot2);
		coordinator.responsibleFor(attendant2);
		
		Object token = coordinator.park(car());
		assertTrue(lot1.hasCarFor(token));
	}
	
	public void testCoordinatorCannotParkCarsIfAllAttendantsHaveAllLotsFull() throws Exception {
		ParkingComplex coordinator = ParkingComplex.firstLotParker();

		ParkingSpace fullLot = new ParkingLot(1);
		fullLot.park(car());
		ParkingComplex attendant1 = ParkingComplex.firstLotParker();
		attendant1.responsibleFor(fullLot);
		coordinator.responsibleFor(attendant1);

		try {
			coordinator.park(car());
			fail("Shouldn't be able to park since none of the attendants have lots with space");
		} catch (CannotParkException expected) {
		}
	}
	
	public void testCoordinatorCanParkInto1Lot() throws Exception {
		ParkingComplex coordinator = ParkingComplex.firstLotParker();
		
		ParkingLot lot = new ParkingLot(1);
		coordinator.responsibleFor(lot);
		Object token = coordinator.park(car());
		assertTrue(lot.hasCarFor(token));
	}
	
	public void testCoordinatorCanParkInto1stLotEvenWhileHandling2Lots() throws Exception {
		ParkingComplex coordinator = ParkingComplex.firstLotParker();
		
		ParkingLot lot1 = new ParkingLot(1);
		coordinator.responsibleFor(lot1);
		ParkingLot lot2 = new ParkingLot(2);
		coordinator.responsibleFor(lot2);
		Object token = coordinator.park(car());
		assertTrue(lot1.hasCarFor(token));
	}
	
	private Object car() {
		return new Object();
	}

}
