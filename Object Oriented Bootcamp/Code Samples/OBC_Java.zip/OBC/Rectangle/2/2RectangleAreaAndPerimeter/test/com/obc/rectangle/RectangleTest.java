package com.obc.rectangle;

import src.Rectangle;
import junit.framework.TestCase;

// Ensures correctness of Rectangle
public class RectangleTest extends TestCase {
	
	private Rectangle rectangle1x1;
	private Rectangle rectangle3x5;

	protected void setUp() {
		rectangle1x1 = new Rectangle(1,1);
		rectangle3x5 = new Rectangle(3,5);
	}

	public void testArea() {
		assertEquals(1, rectangle1x1.area());
		assertEquals(15, rectangle3x5.area());
	}
	
	public void testPerimeter() {
		assertEquals(4, rectangle1x1.perimeter());
		assertEquals(16, rectangle3x5.perimeter());
	}
	
}
