$:.unshift File.dirname(__FILE__)
require 'test/unit'
require 'chance'

module Bootcamp
  module Probability
  
    # Ensures the Chance works correctly.
    class TestChance < Test::Unit::TestCase
    
      VERY_LIKELY = Chance.new(0.8125)
      LIKELY = Chance.new(0.75)
      EQUALLY_LIKELY = Chance.new(0.5)
      UNLIKELY = Chance.new(0.25)
      VERY_UNLIKELY = Chance.new(0.125)
      
      def test_equals
        assert_equal(Chance.new(0.25), UNLIKELY)
        assert_not_equal(LIKELY, UNLIKELY)
      end
      
      def test_not
        assert_equal(UNLIKELY, LIKELY.not)
        assert_equal(LIKELY, LIKELY.not.not)
      end
      
      def test_and
        assert_equal(UNLIKELY, EQUALLY_LIKELY.and(EQUALLY_LIKELY))
        assert_equal(VERY_UNLIKELY, UNLIKELY.and(EQUALLY_LIKELY))
        assert_equal(VERY_UNLIKELY, EQUALLY_LIKELY.and(UNLIKELY))
      end
      
      def test_or
        assert_equal(LIKELY, EQUALLY_LIKELY.or(EQUALLY_LIKELY))
        assert_equal(VERY_LIKELY, LIKELY.or(UNLIKELY))
      end
    end
  end
end