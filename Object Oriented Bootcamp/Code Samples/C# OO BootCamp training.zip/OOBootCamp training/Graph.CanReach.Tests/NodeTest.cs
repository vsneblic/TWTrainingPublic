﻿using NUnit.Framework;

namespace Graph.CanReach.Tests
{
    [TestFixture]
    public class NodeTest
    {
        private Node _nodeA;
        private Node _nodeB;
        private Node _nodeC;
        private Node _nodeX;

        [SetUp]
        public void SetUp()
        {
            _nodeA = new Node("A");
            _nodeB = new Node("B");
            _nodeC = new Node("C");
            _nodeX = new Node("X");
        }

        [Test]
        public void Node_should_be_able_to_reach_self()
        {
            Assert.That(_nodeA.CanReach(_nodeA), Is.True);
        }

        [Test]
        public void Node_should_not_be_able_to_reach_a_non_existing_node()
        {
            Assert.That(_nodeA.CanReach(_nodeX), Is.False);
        }

        [Test]
        public void Node_should_be_able_to_reach_its_neighbors()
        {
            _nodeA.AddNeighbor(_nodeB);
            Assert.That(_nodeA.CanReach(_nodeB), Is.True);
        }

        [Test]
        public void Node_should_be_able_to_reach_its_neighbor_neighboor()
        {
            _nodeA.AddNeighbor(_nodeB);
            _nodeB.AddNeighbor(_nodeC);
            Assert.That(_nodeA.CanReach(_nodeC), Is.True);
        }

        [Test]
        public void Node_CanReach_should_work_in_presence_of_cycles()
        {
            _nodeA.AddNeighbor(_nodeB);
            _nodeB.AddNeighbor(_nodeA);
 
            Assert.That(_nodeA.CanReach(_nodeX), Is.False);            
        }

        [Test]
        public void Node_CanReach_should_work_in_presence_of_a_self_cycles()
        {
            _nodeA.AddNeighbor(_nodeA);

            Assert.That(_nodeA.CanReach(_nodeX), Is.False);
        }
    }
}
