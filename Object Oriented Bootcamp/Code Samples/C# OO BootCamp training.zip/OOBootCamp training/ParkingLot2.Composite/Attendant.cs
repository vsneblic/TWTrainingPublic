﻿using System;
using System.Collections.Generic;

namespace ParkingLot2.Composite
{
    public class Attendant : IParkingService
    {
        private static readonly ParkingServiceFullnessComparer Comparer = new ParkingServiceFullnessComparer();

        private readonly List<IParkingService> _parkingServices;

        public Attendant()
        {
            _parkingServices = new List<IParkingService>();
        }

        public void Attend(IParkingService parkingLotOrAnotherAttendant)
        {
            _parkingServices.Add(parkingLotOrAnotherAttendant);
        }

        public double PercentageFull {
            get
            {
                if (_parkingServices.Count == 0)
                {
                    return 100.0;
                }

                _parkingServices.Sort(Comparer);
                return _parkingServices[0].PercentageFull;
            }
        }

        public void ParkCar(Car carToPark)
        {
            if (_parkingServices.Count == 0)
            {
                throw new InvalidOperationException("No parking lots attended by this attendant. Cannot park the car.");
            }
            _parkingServices.Sort(Comparer);
            _parkingServices[0].ParkCar(carToPark);
        }
    }
}