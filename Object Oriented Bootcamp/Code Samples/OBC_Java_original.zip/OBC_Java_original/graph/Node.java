package graph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
/**
 * 	Understands its neighbors.
 */
public class Node {

	private final Collection<Link> neighbors;
	private final String name;

	public Node(String name) {
		neighbors = new ArrayList<Link>();
		this.name = name;
	}
	
	public void goesTo(Node target, int cost) {
		this.neighbors.add(new Link(target, cost));
	}

	public boolean canReach(Node target) {
		return paths(target, noneSeen()).count() != 0;
	}

	public int hopsTo(Node target) throws UnreachableTargetException {
		return pathTo(target, Path.SHORTEST).length();
	}
	
	public int costTo(Node target) throws UnreachableTargetException {
		return pathTo(target).cost();
	}

	public Path pathTo(Node target) throws UnreachableTargetException {
		return pathTo(target, Path.CHEAPEST);
	}

	Path pathTo(Node target, Comparator<Path> comparator) throws UnreachableTargetException {
		Paths paths = paths(target);
		if (paths.isEmpty()) throw new UnreachableTargetException(this, target);
		return paths.pathTo(comparator);
	}
	
	private Set<Node> copyAddingThis(Set<Node> visited) {
		visited = new HashSet<Node>(visited);
		visited.add(this);
		return visited;
	}

	private Set<Node> noneSeen() {
		return new HashSet<Node>();
	}

	public Paths paths(Node target) {
		return paths(target, noneSeen()).origin(this);
	}

	Paths paths(Node target, Set<Node> visited) {
		if (this == target) return new Paths(new Path());
		if (visited.contains(this)) return null;
		return neighborsPaths(target, copyAddingThis(visited));
	}

	private Paths neighborsPaths(Node target, Set<Node> visited) {
		Paths paths = new Paths();
		for (Link neighbor : neighbors)
			paths.add(neighbor.paths(target, visited));	
		return paths;
	}
}
