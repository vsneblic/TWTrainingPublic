package graph;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.BeforeClass;
import org.junit.Test;

/**
 *  Ensures the correctness of Node.
 */
public class GraphTest {
	private static final Node A = new Node("A");
	private static final Node B = new Node("B");
	private static final Node C = new Node("C");
	private static final Node D = new Node("D");
	private static final Node E = new Node("E");
	private static final Node F = new Node("F");
	private static final Node G = new Node("G");
	private static final Node H = new Node("H");
	
	@BeforeClass
	public static void graph() {
		A.goesTo(F, 6);
		B.goesTo(A, 5);
		B.goesTo(C, 1);
		C.goesTo(D, 2);
		C.goesTo(E, 7);
		C.goesTo(E, 8);
		D.goesTo(E, 3);
		E.goesTo(B, 4);
		H.goesTo(B, 1);
	}

	@Test
	public void shouldReach() {
		assertReachable(A, A, F);
		assertReachable(B, A, B, C, D, E, F);
		assertReachable(C, A, B, C, D, E, F);
		assertReachable(D, D, E);
		assertReachable(E, A, B, C, D, E, F);
		assertReachable(F, F);
		assertReachable(G, G);
		assertReachable(H, A, B, C, D, E, F, H);
	}
	
	@Test
	public void shouldNotReach() throws UnreachableTargetException {
		assertUnreachable(A, B, C, D, E, G, H);		
		assertUnreachable(B, G, H);		
		assertUnreachable(C, G, H);
		assertUnreachable(D, G, H);
		assertUnreachable(E, G, H);
		assertUnreachable(F, A, B, C, G, H);
		assertUnreachable(G, A, B, C, D, E, F);
		assertUnreachable(H, G);
	}

	@Test
	public void shouldCountHops() throws UnreachableTargetException {
		assertNoHops(A, A);
		assertNoHops(B, B);
		assertNoHops(C, C);
		assertNoHops(D, D);
		assertNoHops(E, E);
		assertNoHops(F, F);
		assertNoHops(G, G);
		assertNoHops(H, H);

		assertOneHop(A, F);
		assertOneHop(B, A, C);
		assertOneHop(C, D, E);
		assertOneHop(D, E);
		assertOneHop(E, B);
		assertOneHop(H, B);
		
		assertTwoHops(B, E, F);
		assertTwoHops(C, B);
		assertTwoHops(D, B);

		assertThreeHops(C, A);
		assertThreeHops(D, A);
		assertThreeHops(E, F);
		
		assertFourHops(D, F);
	}
	
	@Test
	public void shouldNotBeAbleToCountUnreachableHops() {
		assertCantCountHops(A, B, C, D, E, G, H);
		assertCantCountHops(B, G, H);
		assertCantCountHops(C, G, H);
		assertCantCountHops(D, G, H);
		assertCantCountHops(E, G, H);
		assertCantCountHops(F, A, B, C, D, E, G, H);
		assertCantCountHops(G, A, B, C, D, E, F, H);
		assertCantCountHops(H, G);
	}

	@Test
	public void shouldDetermineCost() throws UnreachableTargetException {
		assertNoCost(A, A);
		assertNoCost(B, B);
		assertNoCost(C, C);
		assertNoCost(D, D);
		assertNoCost(E, E);
		assertNoCost(F, F);
		assertNoCost(G, G);
		assertNoCost(H, H);

		assertCostTo(6, A, F);
		assertCostTo(5, B, A);
		assertCostTo(1, B, C);
		assertCostTo(6, B, E);
		assertCostTo(11, B, F);
		assertCostTo(14, C, A);
		assertCostTo(9, C, B);
		assertCostTo(2, C, D);
		assertCostTo(5, C, E);
		assertCostTo(12, D, A);
		assertCostTo(7, D, B);
		assertCostTo(3, D, E);
		assertCostTo(18, D, F);
		assertCostTo(4, E, B);
		assertCostTo(15, E, F);
		assertCostTo(1, H, B);		
	}

	@Test
	public void shouldNotBeAbleToDetermineCostForUnreachableHops() {
		assertCantDetermineCost(A, B, C, D, E, G, H);
		assertCantDetermineCost(B, G, H);
		assertCantDetermineCost(C, G, H);
		assertCantDetermineCost(D, G, H);
		assertCantDetermineCost(E, G, H);
		assertCantDetermineCost(F, A, B, C, D, E, G, H);
		assertCantDetermineCost(G, A, B, C, D, E, F, H);
		assertCantDetermineCost(H, G);
	}
	
	@Test
	public void shouldBeAbleToFindAllPaths() {
		assertPaths(1, A, A, F);
		assertPaths(0, A, B, C, D, E, G, H);
		assertPaths(0, B, G, H);
		assertPaths(1, B, A, B, C, D, F);
		assertPaths(3, B, E);		
		assertPaths(0, C, G, H);
		assertPaths(1, C, C, D);
		assertPaths(3, C, A, B, E, F);
		assertPaths(1, D, D);
		assertPaths(1, E, E);
		assertPaths(1, F, F);
		assertPaths(1, G, G);
		assertPaths(1, H, H);
	}
	
	private void assertReachable(Node start, Node ... targets) {
		for (Node target : targets)
			assertTrue(start.canReach(target));
	}

	private void assertUnreachable(Node start, Node ... targets) {
		for (Node target : targets)
			assertFalse(start.canReach(target));
	}

	private void assertNoHops(Node start, Node ... targets) throws UnreachableTargetException {
		assertHopsTo(0, start, targets);
	}

	private void assertOneHop(Node start, Node ... targets) throws UnreachableTargetException {
		assertHopsTo(1, start, targets);
	}

	private void assertThreeHops(Node start, Node ... targets) throws UnreachableTargetException {
		assertHopsTo(3, start, targets);
	}

	private void assertFourHops(Node start, Node ... targets) throws UnreachableTargetException {
		assertHopsTo(4, start, targets);
	}

	private void assertTwoHops(Node start, Node ... targets) throws UnreachableTargetException {
		assertHopsTo(2, start, targets);
	}

	private void assertHopsTo(int hops, Node start, Node... targets) throws UnreachableTargetException {
		for (Node target : targets)
			assertEquals(hops, start.hopsTo(target));
	}

	private void assertCantCountHops(Node start, Node ... targets) {
		for (Node target : targets)
			assertCantCountHops(start, target);
	}

	private void assertCantCountHops(Node start, Node target) {
		try {
			start.hopsTo(target);
			fail("Expected UnreachableTargetException");
		}
		catch (UnreachableTargetException e) {};
	}
	
	private void assertNoCost(Node start, Node ... targets) throws UnreachableTargetException {
		assertCostTo(0, start, targets);
	}	

	private void assertCostTo(int cost, Node start, Node... targets) throws UnreachableTargetException {
		for (Node target : targets) {
			assertEquals(cost, start.pathTo(target).cost());
		}
	}

	private void assertCantDetermineCost(Node start, Node ... targets) {
		for (Node target : targets)
			assertCantDetermineCost(start, target);
	}

	private void assertCantDetermineCost(Node start, Node target) {
		try {
			start.costTo(target);
			fail("Expected UnreachableTargetException");
		}
		catch (UnreachableTargetException e) {};
		try {
			start.pathTo(target).cost();
			fail("Expected UnreachableTargetException");
		}
		catch (UnreachableTargetException e) {};
	}

	private void assertPaths(int paths, Node start, Node ... targets) {
		for (Node target : targets)
			assertPathsTo(paths, start, target);
	}

	private void assertPathsTo(int paths, Node start, Node target) {
		assertEquals(paths, start.paths(target).count());
	}
}
