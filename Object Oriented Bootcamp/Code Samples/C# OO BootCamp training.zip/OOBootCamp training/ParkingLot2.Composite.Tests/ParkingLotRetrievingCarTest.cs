﻿using System;
using NUnit.Framework;

namespace ParkingLot2.Composite.Tests
{
    [TestFixture]
    public class ParkingLotRetrievingCarTest
    {
        private ParkingLot _target;
        private Car _car;

        [SetUp]
        public void SetUp()
        {
            _target = new ParkingLot(capacity: 3);
            _car = new Car();
        }

        [Test]
        public void After_parking_a_car_should_be_possible_to_retrieve_a_car()
        {
            _target.ParkCar(_car);

            _target.RetrieveCar(_car);
        }

        [Test]
        public void Retrieving_a_car_in_an_empty_parking_lot_should_raise_an_error()
        {
            var anyCar = new Car();

            Assert.Throws<InvalidOperationException>(() => _target.RetrieveCar(anyCar));
        }

        [Test]
        public void Retrieving_a_non_parked_car_should_raise_an_error()
        {
            var car = new Car();
            var aDifferentCar = new Car();

            _target.ParkCar(car);

            Assert.Throws<InvalidOperationException>(() => _target.RetrieveCar(aDifferentCar));
        }
    }
}
