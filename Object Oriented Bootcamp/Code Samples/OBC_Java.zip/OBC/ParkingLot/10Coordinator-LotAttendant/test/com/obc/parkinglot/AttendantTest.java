package com.obc.parkinglot;

import java.util.List;

import junit.framework.TestCase;

// Ensures correctness of an attendant
public class AttendantTest extends TestCase {

	private Object carA = new Object();
	private Object carB = new Object();
	private Object carC = new Object();

	private Attendant attendant;
	private ParkingLot lot2;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		attendant = Attendant.firstLotParker(); 

		lot2 = makeLotForAttendant(attendant, 2);
	}

	private ParkingLot makeLotForAttendant(Attendant attendant, int capacity) {
		ParkingLot lot = new ParkingLot(capacity);
		attendant.responsibleFor(lot);
		return lot;
	}

	public void testAttendantWithOneLotDirectsCarToThatLot() throws Exception {
		attendant.direct(carA);
		assertTrue(lot2.hasCar(carA));
	}

	public void testAttendantWithTwoLotsDirectsCarToFirstLot() throws Exception {
		makeLotForAttendant(attendant, 3);
		attendant.direct(carA);
		assertTrue(lot2.hasCar(carA));
	}

	public void testAttendantWithTwoLotsDirectsCarToLotWithSpace()
			throws Exception {
		lot2.park(carA);
		ParkingLot lot3 = makeLotForAttendant(attendant, 3);
		lot2.park(carB);
		attendant.direct(carC);
		assertTrue(lot3.hasCar(carC));
	}

	public void testAttendantCanUnparkFromOneLot() throws Exception {
		Object token = attendant.direct(carA);
		assertSame(carA, attendant.unpark(token));
	}

	public void testAttendantCanUnparkFromMultipleLots() throws Exception {
		lot2.park(carA);
		lot2.park(carB);
		makeLotForAttendant(attendant, 3);
		Object token = attendant.direct(carC);
		assertSame(carC, attendant.unpark(token));
	}

	public void testAttendantWithAllLotsFullCannotParkTheCar() throws Exception {
		lot2.park(carA);
		lot2.park(carB);

		try {
			attendant.direct(carC);
			fail("Attendant shouldn't be able to direct a car if all lots are full");
		} catch (CannotParkException expected) {
		}
	}

	public void testAttendantCanParkIntoAFullLotAfterItHasSpaceAgain()
			throws Exception {
		lot2.park(carA);
		Object token = lot2.park(carB);
		lot2.unpark(token);
		attendant.direct(carC);
		assertTrue(lot2.hasCar(carC));
	}
	
	public void testAttendantDirectsCarToLotWithMostFreeSpace() throws Exception {
		attendant = Attendant.mostFreeLotParker(); 
		attendant.responsibleFor(lot2);
		ParkingLot lot3 = makeLotForAttendant(attendant, 3);
		attendant.direct(carA);
		assertTrue(lot3.hasCar(carA));
	}
	
	public void testAttendantHandling3LotsDirectsCarToLotWithMostFreeSpace() throws Exception {
		attendant = Attendant.mostFreeLotParker();
		attendant.responsibleFor(lot2);
		makeLotForAttendant(attendant, 3);
		ParkingLot lot4 = makeLotForAttendant(attendant, 4);
		attendant.direct(carA);
		assertTrue(lot4.hasCar(carA));
	}
	
	public void testAttendantDirectsCarToLotWithMostCapacity() throws Exception {
		attendant = Attendant.mostCapacityLotParker();		
		makeLotForAttendant(attendant, 2);
		ParkingLot lot3 = makeLotForAttendant(attendant, 3);
		lot3.park(carA);
		lot3.park(carB);
		attendant.direct(carC);
		assertTrue(lot3.hasCar(carC));
	}
	
	public void testAttendantWith3LotsDirectsCarToLotWithMostCapacity() throws Exception {
		attendant = Attendant.mostCapacityLotParker();		
		makeLotForAttendant(attendant, 2);
		makeLotForAttendant(attendant, 3);
		ParkingLot lot4 = makeLotForAttendant(attendant, 4);
		lot4.park(carA);
		attendant.direct(carC);
		assertTrue(lot4.hasCar(carC));		
	}
	
	public void testAttendantDirectsCarsToCheapestLot() throws Exception {
		attendant = Attendant.mostCapacityLotParker();
		makeLotForAttendant(1, 10);
		ParkingLot rs5Lot = makeLotForAttendant(3, 5);
		Object token = attendant.direct(carA, LotSelectionMethod.CHEAPEST);
		assertTrue(rs5Lot.hasCarFor(token));		
	}
	
	public void testAttendantWith3LotsDirectsCarsToCheapestLot() throws Exception {
		attendant = Attendant.mostCapacityLotParker();
		makeLotForAttendant(1, 10);
		makeLotForAttendant(2, 15);
		ParkingLot rs5Lot = makeLotForAttendant(3, 5);
		Object token = attendant.direct(carA, LotSelectionMethod.CHEAPEST);
		assertTrue(rs5Lot.hasCarFor(token));				
	}
	
	public void testAttendantCannotDirectCarsToCheapestLotIfAllLotsAreFull() throws Exception {
		attendant = Attendant.mostCapacityLotParker();
		try {
			attendant.direct(carA, LotSelectionMethod.CHEAPEST);
			fail("Shouldn't be able to park a car if there are no available lots");
		} catch (CannotParkException expected) {
		}
	}

	private ParkingLot makeLotForAttendant(int capacity, int cost) {
		ParkingLot lot = new ParkingLot(capacity, cost);
		attendant.responsibleFor(lot);
		return lot;
	}
	
}
