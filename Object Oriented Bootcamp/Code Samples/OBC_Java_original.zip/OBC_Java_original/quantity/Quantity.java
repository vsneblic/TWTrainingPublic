package quantity;

/**
 * 	Understands scalars in a particular Unit.
 */
public class Quantity {

	final Unit unit;
	final double amount;

	public Quantity(Unit unit, double amount) {
		this.unit = unit;
		this.amount = amount;
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other == null) return false;
		if (this.getClass() != other.getClass()) return false;
		return this.equals((Quantity)other);
	}

	boolean equals(Quantity other) {
		if (this.unit.equals(other.unit)) return this.amount == other.amount;
		if (!this.unit.sameTypeAs(other.unit)) return false;
		return this.amount == other.amountIn(this.unit);
	}


	double amountIn(Unit base) {
		return unit.amountIn(amount, base);
	}

	@Override
	public String toString() {
		return amount + " " + unit;
	}
}