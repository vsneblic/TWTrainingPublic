module Bootcamp
  module Graph
  
    # Understands a way to traverse from one Node to another
    class Path
      
      def initialize()
        @links = []
      end
      
      def <<(link)
        @links << link
        self
      end
      
      def hop_count
        @links.size
      end
      
      def cost
        @links.inject(0) {|total, link| total + link.cost}
      end
      
      def lesser(other, strategy)
        strategy.call(self, other) < 0 ? self : other
      end
      
      def source=(source)
        @source = source
      end
        
    end
    
  end
end