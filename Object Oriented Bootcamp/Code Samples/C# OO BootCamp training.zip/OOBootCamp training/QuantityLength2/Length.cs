﻿
using System;
using System.Collections.Generic;

namespace QuantityLength2
{
    public class Length
    {
        private static readonly Dictionary<UnitOfLength, double> ConvertionFactorToInchesFrom = new Dictionary<UnitOfLength, double>()
            {
                { UnitOfLength.Inch, 1 },
                { UnitOfLength.Feet, 12.0 },
                { UnitOfLength.Yard, 36.0 },
                { UnitOfLength.Mile, 36.0 * 1760.0 }
            };

        private readonly UnitOfLength _unitOfLength;
        private readonly double _value;
        private readonly double _conversionFactorToInches;

        public Length(UnitOfLength unitOfLength, double value)
            : this(unitOfLength, value, ConvertionFactorToInchesFrom[unitOfLength])
        {
        }

        private Length(UnitOfLength unitOfLength, double value, double conversionFactorToInches)
        {
            _unitOfLength = unitOfLength;
            _value = value;
            _conversionFactorToInches = conversionFactorToInches;
        }

        public bool IsEquivalentTo(Length other)
        {
            return ToInches() == other.ToInches();
        }

        private double ToInches()
        {
            return _value * _conversionFactorToInches;
        }

        public static Length operator +(Length leftValue, Length rightValue)
        {
            if (leftValue._unitOfLength != rightValue._unitOfLength)
            {
                throw new ArgumentException("Addition between two different unit of length.");
            }

            return new Length(leftValue._unitOfLength, leftValue._value + rightValue._value);
        }
    }
}
