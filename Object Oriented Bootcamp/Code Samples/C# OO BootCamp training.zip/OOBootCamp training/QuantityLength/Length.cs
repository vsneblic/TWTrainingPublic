﻿
using System.Collections.Generic;

namespace QuantityLength
{
    public class Length
    {
        private readonly UnitOfLength _unitOfLength;
        private readonly double _value;

        private readonly Dictionary<UnitOfLength, double> _convertionFactorFromInchesTo = new Dictionary<UnitOfLength, double>();
        private readonly Dictionary<UnitOfLength, double> _convertionFactorFromFeetTo = new Dictionary<UnitOfLength, double>();
        private readonly Dictionary<UnitOfLength, Dictionary<UnitOfLength, double>> _convertionFactor;
 
        public Length(UnitOfLength unitOfLength, double value)
        {
            _unitOfLength = unitOfLength;
            _value = value;

            _convertionFactorFromInchesTo[UnitOfLength.Feet] = 1.0 / 12.0;
            _convertionFactorFromFeetTo[UnitOfLength.Inch] = 12.0;

            _convertionFactor = new Dictionary<UnitOfLength, Dictionary<UnitOfLength, double>>();
            _convertionFactor[UnitOfLength.Inch] = _convertionFactorFromInchesTo;
            _convertionFactor[UnitOfLength.Feet] = _convertionFactorFromFeetTo;
        }

        public bool IsEquivalentTo(Length other)
        {
            return _value == (other._value * ConvertionFactor(other._unitOfLength, _unitOfLength));
        }

        private double ConvertionFactor(UnitOfLength from, UnitOfLength to)
        {
            if (from == to)
            {
                return 1;
            }

            return _convertionFactor[from][to];
        }
    }
}
