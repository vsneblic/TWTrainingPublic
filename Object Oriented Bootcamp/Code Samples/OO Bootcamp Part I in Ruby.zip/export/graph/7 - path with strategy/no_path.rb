module Bootcamp
  module Graph
  
    # Understands there is no way to traverse from one Node to another
    class NoPath
      $NO_PATH = NoPath.new
      private_class_method :new
      
      INFINITY = 1.0/0.0
      
      def <<(link)
        self
      end
      
      def hop_count
        INFINITY
      end
      
      def cost
        INFINITY
      end
      
      def <=>(other)
        other.instance_of?(NoPath) ? 0 : 1
      end
      
      def lesser(other, strategy)
        other
      end
        
    end
    
  end
end