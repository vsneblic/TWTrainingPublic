package q2;

import static q2.Quantity.TSP_ID;
import static org.junit.Assert.*;

import org.junit.Test;

public class QuantityTest {

	@Test
	public void shouldeAbleToCompareLiquids() {
		//assertEquals(new Quantity(TSP_ID, 3), new Quantity(TSP_ID, 3));
	}
}
