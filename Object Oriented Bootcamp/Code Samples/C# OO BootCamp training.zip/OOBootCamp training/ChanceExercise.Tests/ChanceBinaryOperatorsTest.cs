﻿using NUnit.Framework;

namespace ChanceExercise.Tests
{
    [TestFixture]
    class ChanceBinaryOperatorsTest
    {
        private double _leftProbability;
        private double _rightProbability;

        private Chance _leftChance;
        private Chance _rightChance;

        private Chance _anyChance;

        private Chance _impossible;
        private Chance _certain;
        private Chance _likely;
        private Chance _unlikely;

        [SetUp]
        public void SetUp()
        {
            _leftProbability = 0.131;
            _rightProbability = 0.97;

            _leftChance = new Chance(_leftProbability);
            _rightChance = new Chance(_rightProbability);

            _anyChance = new Chance(0.579);

            _impossible = new Chance(0);
            _certain = new Chance(1);

            _likely = new Chance(0.75);
            _unlikely = new Chance(0.25);
        }

        [Test]
        public void The_and_of_any_chance_and_impossible_chance_is_equal_to_impossible()
        {
            var result = _anyChance & _impossible;

            Assert.That(result, Is.EqualTo(_impossible));
        }

        [Test]
        public void The_and_of_any_chance_and_the_certain_chance_is_equal_to_the_first_chance()
        {
            var result = _anyChance & _certain;

            Assert.That(result, Is.EqualTo(_anyChance));
        }

        [Test]
        public void The_and_of_Likely_and_Unlikely_is_equal_to_VeryUnlikely()
        {
	        var veryUnlikely = new Chance(0.1875);

            Assert.That(_likely & _unlikely, Is.EqualTo(veryUnlikely));
        }

        [Test]
        public void The_and_of_two_chances_is_equal_to_the_chance_of_the_product_of_the_two_probabilities()
        {
            var result = _leftChance & _rightChance;
            var expectedResult = new Chance(_leftProbability * _rightProbability);

            Assert.That(result, Is.EqualTo(expectedResult));
        }

        [Test]
        public void The_and_of_any_two_chances_is_symmetric()
        {
            Assert.That(_leftChance & _rightChance, Is.EqualTo(_rightChance & _leftChance));
        }

        [Test]
        public void The_or_of_any_chance_and_impossible_is_equal_to_the_first_chance()
        {
            var result = _anyChance | _impossible;

            Assert.That(result, Is.EqualTo(_anyChance));
        }

        [Test]
        public void The_or_of_any_chanche_and_certain_chance_is_equant_to_certain()
        {
            var result = _anyChance | _certain;

            Assert.That(result, Is.EqualTo(_certain));
        }

        [Test]
        public void The_or_of_Likely_and_Unlikely_is_equal_to_VeryLikely()
        {
            var veryUnlikely = new Chance(0.8125);

            Assert.That(_likely | _unlikely, Is.EqualTo(veryUnlikely));
        }

        [Test]
        public void The_or_of_two_chances_is_equal_to_the_probability_of_two_indipendent_events()
        {
            var result = _leftChance | _rightChance;
            var twoIndpendenEventsProbability =
                new Chance(_leftProbability + _rightProbability - _leftProbability*_rightProbability);

            Assert.That(result, Is.EqualTo(twoIndpendenEventsProbability));
        }

        [Test]
        public void The_or_of_two_chances_is_symmetric()
        {
            Assert.That(_leftChance | _rightChance, Is.EqualTo(_rightChance | _leftChance));            
        }
    }
}
