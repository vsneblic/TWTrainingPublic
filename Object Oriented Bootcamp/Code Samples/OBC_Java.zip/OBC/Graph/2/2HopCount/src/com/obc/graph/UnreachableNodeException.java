package com.obc.graph;

// Understands the reason for not being able to reach the destination from the source
public class UnreachableNodeException extends Exception {

	public UnreachableNodeException(String message) {
		super(message);
	}	
}
