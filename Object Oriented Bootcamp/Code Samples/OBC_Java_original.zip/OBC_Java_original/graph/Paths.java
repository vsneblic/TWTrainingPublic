package graph;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

/**
 * 	Understands all Paths between two Nodes.
 */
public class Paths {


	private final Collection<Path> paths;

	Paths(Path path) {
		this();
		paths.add(path);
	}
	
	Paths() {
		paths = new HashSet<Path>();
	}

	int count() {
		return paths.size();
	}

	void extendAll(Link link) {
		for (Path path : paths )
			path.prepend(link);
	}

	void add(Paths paths) {
		if (paths != null)
			this.paths.addAll(paths.paths);
	}

	Paths origin(Node origin) {
		for (Path path : paths) {
			path.origin(origin);
		}
		return this;
	}

	Path pathTo(Comparator<Path> comparator) {
		return Collections.min(paths, comparator);
	}

	Paths prepend(Link link) {
		for (Path path : paths) {
			path.prepend(link);
		}
		return this;
	}

	boolean isEmpty() {
		return paths.isEmpty();
	}

}
