package chance;

/**
 * 	Understands the likelihood of an event.
 */
public class Chance {

	private static final int CERTAINTY = 1;
	private final double likelihood;

	public Chance(double likelihood) {
		this.likelihood = likelihood;
	}

	public Chance not() {
		return new Chance(CERTAINTY - likelihood);
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other == null) return false;
		if (this.getClass() != other.getClass()) return false;
		return this.equals((Chance)other);
	}

	private boolean equals(Chance other) {
		return likelihood == other.likelihood;
	}

	public Chance and(Chance other) {
		return new Chance(likelihood * other.likelihood);
	}
	
	//	DeMorgan's Law
	public Chance or(Chance other) {
		return this.not().and(other.not()).not();
	}

    @Override
    public String toString() {
        return "Probability is " + likelihood;
    }

}
