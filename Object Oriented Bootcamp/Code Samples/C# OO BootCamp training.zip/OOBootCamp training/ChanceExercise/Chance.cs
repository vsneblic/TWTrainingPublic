﻿using System;
using System.Globalization;

namespace ChanceExercise
{
    public class Chance
    {
        private readonly double _probability;

        public Chance(double probability)
        {
            if (probability < 0 || 1 < probability)
            {
                throw new ArgumentOutOfRangeException("probability", "Should be between 0 and 1.");
            }

            _probability = probability;
        }

        protected bool Equals(Chance other)
        {
            return _probability.Equals(other._probability);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Chance) obj);
        }

        public override int GetHashCode()
        {
            return _probability.GetHashCode();
        }

        public static Chance operator!(Chance value)
        {
            return new Chance(1 - value._probability);
        }

        public static Chance operator&(Chance leftValue, Chance rightValue)
        {
            return new Chance(leftValue._probability * rightValue._probability);
        }

        public static Chance operator|(Chance leftValue, Chance rightValue)
        {
            return !(!leftValue & !rightValue);
            return new Chance(leftValue._probability + rightValue._probability - (leftValue & rightValue)._probability);
        }

        public override string ToString()
        {
            return _probability.ToString(CultureInfo.InvariantCulture);
        }
    }
}
