package com.obc.parkinglot;

import java.util.ArrayList;
import java.util.List;


// Understands a person responsible for parking lots
public class Attendant {

	private List<ParkingLot> lots = new ArrayList<ParkingLot>();

	public void responsibleFor(ParkingLot lot) {
		lots.add(lot);		
	}

	public Object direct(Object car) throws CannotParkException {
		for (ParkingLot lot : lots) {
			if (!lot.isFull()) return lot.park(car);
		}
		throw CannotParkException.becauseAllLotsAreFull(car, this);
	}

	public Object unpark(Object token) throws CannotUnparkException {
		for (ParkingLot lot : lots) {
			if (lot.hasCarFor(token)) return lot.unpark(token);
		}
		throw new CannotUnparkException(token, this);
	}

}
