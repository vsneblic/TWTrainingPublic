package com.obc.parkinglot;

import java.util.List;

public //Understands different criteria for selecting lots 
abstract class SpaceSelectionMethod {
	public abstract ParkingSpace selectLotToParkInto(List<ParkingSpace> availableSpaces);
	
	public static final SpaceSelectionMethod FIRST_AVAILABLE = new FirstAvailableLot();
	
	
	public static final SpaceSelectionMethod MOST_CAPACITY = new MostCapacityLot();
	
	public static final SpaceSelectionMethod MOST_FREE = new MostFreeLot();
	
	public static final SpaceSelectionMethod CHEAPEST = new SpaceSelectionMethod() {
		@Override
		public ParkingSpace selectLotToParkInto(List<ParkingSpace> availableSpaces) {
			ParkingSpace champion = availableSpaces.get(0);
			for (ParkingSpace challenger : availableSpaces) {
				if (challenger.cost() < champion.cost())
					champion = challenger;
			}
			return champion;
		}
	};
}

// Understands how to select the first lot with space available 
class FirstAvailableLot extends SpaceSelectionMethod {
	@Override
	public ParkingSpace selectLotToParkInto(List<ParkingSpace> availableSpaces) {
		return availableSpaces.get(0);
	}
}

// Understands how to select the lot with maximum capacity
class MostCapacityLot extends SpaceSelectionMethod {
	@Override
	public ParkingSpace selectLotToParkInto(List<ParkingSpace> availableSpaces) {
		ParkingSpace champion = availableSpaces.get(0);
		for (ParkingSpace challenger : availableSpaces) {
			if (challenger.capacity() > champion.capacity())
				champion = challenger;
		}
		return champion;
	}
}

// Understands how to select the lot with the maximum free space
class MostFreeLot extends SpaceSelectionMethod {
	@Override
	public ParkingSpace selectLotToParkInto(List<ParkingSpace> availableSpaces) {
		ParkingSpace champion = availableSpaces.get(0);
		for (ParkingSpace challenger : availableSpaces) {
			if (challenger.freeSpace() > champion.freeSpace())
				champion = challenger;
		}
		return champion;
	}
}
