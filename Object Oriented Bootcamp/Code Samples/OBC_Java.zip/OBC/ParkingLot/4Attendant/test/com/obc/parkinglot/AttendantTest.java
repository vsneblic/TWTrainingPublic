package com.obc.parkinglot;

import junit.framework.TestCase;

// Ensures correctness of an attendant
public class AttendantTest extends TestCase {

	private Object carA = new Object();
	private Object carB = new Object();
	private Object carC = new Object();
	
	private Attendant attendant;
	private ParkingLot lot2;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		attendant = new Attendant();

		lot2 = makeLotForAttendant(attendant, 2);
	}

	private ParkingLot makeLotForAttendant(Attendant attendant, int capacity) {
		ParkingLot lot = new ParkingLot(capacity);
		attendant.responsibleFor(lot);
		return lot;
	}

	public void testAttendantWithOneLotDirectsCarToThatLot() throws Exception {
		attendant.direct(carA);
		assertTrue(lot2.hasCar(carA));
	}

	public void testAttendantWithTwoLotsDirectsCarToFirstLot() throws Exception {
		ParkingLot lot3 = makeLotForAttendant(attendant, 3);
		attendant.direct(carA);
		assertTrue(lot2.hasCar(carA));
	}

	public void testAttendantWithTwoLotsDirectsCarToLotWithSpace()
			throws Exception {
		lot2.park(carA);
		ParkingLot lot3 = makeLotForAttendant(attendant, 3);
		lot2.park(carB);
		attendant.direct(carC);
		assertTrue(lot3.hasCar(carC));
	}
	
	public void testAttendantCanUnparkFromOneLot() throws Exception {
		Object token = attendant.direct(carA);
		assertSame(carA, attendant.unpark(token));
	}
	
	public void testAttendantCanUnparkFromMultipleLots() throws Exception {
		lot2.park(carA);
		lot2.park(carB);
		ParkingLot lot3 = makeLotForAttendant(attendant, 3);
		Object token = attendant.direct(carC);
		assertSame(carC,attendant.unpark(token));
	}

}
