package com.obc.parkinglot;


interface ParkingLotObserver {

	public abstract void notifyFull();

	public abstract void notifyHasSpace();

}