$:.unshift File.dirname(__FILE__)
require 'test/unit'
require 'node'
require 'link'
require 'path'
require 'no_path'
require 'no_path_error'

module Bootcamp
  module Graph

    # Ensures graph algorithms work correctly
    class TestGraph < Test::Unit::TestCase
    
      def setup
        @a = Node.new("a")
        @b = Node.new("b")
        @c = Node.new("c")
        @d = Node.new("d")
        @e = Node.new("e")
        @f = Node.new("f")
        @g = Node.new("g")
        @a.connect_to(@f, 6)
        @b.connect_to(@a, 5)
        @b.connect_to(@c, 1)
        @c.connect_to(@d, 2)
        @c.connect_to(@e, 8)
        @c.connect_to(@e, 7)
        @d.connect_to(@e, 3)
        @e.connect_to(@b, 4)
      end
      
      def test_reach
        assert(@a.reach?(@a))
        assert(@b.reach?(@a))
        assert(!@g.reach?(@a))
        assert(!@a.reach?(@g))
        assert(!@b.reach?(@g))
        assert(@c.reach?(@f))
      end
      
      def test_hop_count
        assert_equal(0, @a.hop_count(@a))
        assert_equal(1, @b.hop_count(@a))
        assert_equal(2, @b.hop_count(@f))
        assert_equal(2, @b.hop_count(@e))
        assert_equal(4, @c.hop_count(@f))
      end
      
      def test_no_path
        assert_no_path(@g, @a)
        assert_no_path(@a, @b)
        assert_no_path(@a, @g)
        assert_no_path(@b, @g)
      end
      
      def test_cost
        assert_equal(0, @a.cost(@a))
        assert_equal(5, @b.cost(@a))
        assert_equal(11, @b.cost(@f))
        assert_equal(6, @b.cost(@e))
        assert_equal(20, @c.cost(@f))
      end
      
      def test_path
        assert_path(@a, @a, 0, 0)
        assert_path(@a, @f, 1, 6)
        assert_path(@c, @e, 2, 5)
        assert_path(@b, @a, 1, 5)
        assert_path(@c, @f, 5, 20)
      end
      
      private
      def assert_no_path(from, to)
        assert_raise(NoPathError) { from.hop_count(to) }
        assert_raise(NoPathError) { from.cost(to) }
        assert_raise(NoPathError) { from.path(to) }
      end
      
      private
      def assert_path(from, to, expected_hops, expected_cost)
        p = from.path(to)
        assert_equal(expected_hops, p.hop_count)
        assert_equal(expected_cost, p.cost)
      end
      
    end

  end
end