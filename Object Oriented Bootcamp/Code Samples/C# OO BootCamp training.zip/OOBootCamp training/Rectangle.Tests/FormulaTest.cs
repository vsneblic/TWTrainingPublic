﻿
using NUnit.Framework;

namespace Rectangle.Tests
{
    [TestFixture]
    public class FormulaTest
    {
        private Rectangle _emptyRectangle;

        [SetUp]
        public void SetUp()
        {
            _emptyRectangle = new Rectangle(0, 0);
        }

        [Test]
        public void Empty_rectangle_perimeter_should_be_zero()
        {
            Assert.That(_emptyRectangle.Perimeter, Is.EqualTo(0));
        }

        [Test]
        public void Five_per_seven_Rectangle_perimeter_should_be_24()
        {
            var target = new Rectangle(5, 7);

            Assert.That(target.Perimeter, Is.EqualTo(24));
        }

        [Test]
        public void Empty_ectangle_area_should_be_zero()
        {
            Assert.That(_emptyRectangle.Area, Is.EqualTo(0));
        }

        [Test]
        public void Tree_per_eleven_Rectangle_area_should_be_33()
        {
            var target = new Rectangle(3, 11);

            Assert.That(target.Area, Is.EqualTo(33));
        }

    }
}
