package parking;


public interface ParkingLotObserver {

	void notify(int cars, int capacity, ParkingLot lot);
}