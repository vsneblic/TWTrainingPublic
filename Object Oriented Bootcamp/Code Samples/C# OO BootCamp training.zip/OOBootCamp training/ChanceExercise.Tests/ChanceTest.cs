﻿using System;
using NUnit.Framework;

namespace ChanceExercise.Tests
{

    [TestFixture]
    public class ChanceTest
    {
        private Chance _anyChance;
        private double _anyProbability;

        [SetUp]
        public void SetUp()
        {
            _anyChance = new Chance(0.579);
            _anyProbability = 0.9876;
        }

        [Test]
        public void A_chance_lower_then_zero_should_raise_an_error()
        {
            Assert.Throws<ArgumentOutOfRangeException>( () => { new Chance(-0.1); } );
        }

        [Test]
        public void A_chance_higher_then_one_shoould_raise_an_error()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => { new Chance(1.1); });
        }


        [Test]
        public void The_negation_of_a_chanche_is_equal_to_the_chance_of_the_negated_probability()
        {
            var target = new Chance(_anyProbability);

            Assert.That(!target, Is.EqualTo( new Chance(1 - _anyProbability )));
        }

        [Test]
        public void The_negation_of_an_impossible_chance_is_equal_to_certainty()
        {
	        var certain = new Chance(1);
	        var impossible = new Chance(0);
            var target = impossible;

            Assert.That(!target, Is.EqualTo(certain));
        }

        [Test]
        public void The_double_negation_of_a_chance_is_equal_to_self()
        {
            Assert.That(!!_anyChance, Is.EqualTo(_anyChance));
        }
    }
}
