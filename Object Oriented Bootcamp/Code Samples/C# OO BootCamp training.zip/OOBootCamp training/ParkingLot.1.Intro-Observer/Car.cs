﻿namespace ParkingLot1.Intro_Observer
{
    public class Car {}
}