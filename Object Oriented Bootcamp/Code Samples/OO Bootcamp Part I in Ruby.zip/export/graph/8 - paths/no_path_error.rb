module Bootcamp
  module Graph

    # Understands that no path was found from one particular
    # Node to another
    class NoPathError < RuntimeError
      
    end
  end
end