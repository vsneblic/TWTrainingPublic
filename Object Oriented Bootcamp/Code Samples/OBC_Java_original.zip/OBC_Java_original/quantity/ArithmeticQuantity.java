package quantity;

/**
 * 	Understands the number of similar ArithmeticUnits.
 */
public class ArithmeticQuantity extends Quantity {

	ArithmeticQuantity(Unit unit, double amount) {
		super(unit, amount);
	}

	public ArithmeticQuantity add(ArithmeticQuantity other) {
		if (!this.unit.sameTypeAs(other.unit))
			throw new UnitMismatchException(unit, other.unit);
		return new ArithmeticQuantity(unit, amount + other.amountIn(unit));
	}
}
