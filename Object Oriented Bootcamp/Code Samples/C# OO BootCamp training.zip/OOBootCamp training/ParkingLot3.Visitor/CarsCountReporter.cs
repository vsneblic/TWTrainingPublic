﻿using System.Collections.Generic;

namespace ParkingLot3.Visitor
{
    public class CarsCountReporter : IParkingServicesTourReporter
    {
        private readonly Dictionary<ParkingLot, string> _visitedParkingLot = new Dictionary<ParkingLot, string>();
        private  string _report = "";

        public void CollectInformation(Attendant attendant, List<IParkingService> parkingServices)
        {
            parkingServices.ForEach(p => p.ParkingServicesTour(this));
        }

        public void CollectInformation(ParkingLot parkingLot, int capacity, int parkedCarsCount)
        {
            if (_visitedParkingLot.ContainsKey(parkingLot))
            {
                return;
            }

            _visitedParkingLot[parkingLot] = ((char)('A' + _visitedParkingLot.Count)).ToString();
            _report += (string.Format("Parking Lot {0}: available spaces {1}.\n", _visitedParkingLot[parkingLot], capacity - parkedCarsCount));
        }

        public string Report
        {
            get { return _report; }
        }
    }
}