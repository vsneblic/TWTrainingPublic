package com.obc.quantity;

// Understands an operation performed on incompatible metrics  
public class IncompatibleUnitsException extends Exception {

	public IncompatibleUnitsException(String message) {
		super(message);
	}
}
