package com.obc.length;

import src.Length;
import junit.framework.TestCase;

// Ensures correctness of Length
public class LengthTest extends TestCase {

	private Length foot1;
	private Length inch12;

	protected void setUp() {
		foot1 = Length.foot(1);
		inch12 = Length.inch(12);
	}

	public void testSameUnitEquals() {
		assertEquals(foot1, Length.foot(1));
		assertFalse(foot1.equals(Length.foot(2)));
		assertFalse(foot1.equals(null));
		assertFalse(foot1.equals(new Object()));
	}

	public void testDifferentUnitEquals() throws Exception {
		assertFalse(foot1.equals(Length.inch(1)));
		assertEquals(foot1, inch12);
		assertEquals(inch12, foot1);
	}
	
	public void testYardEquals() throws Exception {
		assertEquals(Length.foot(3), Length.yard(1));
	}
}
