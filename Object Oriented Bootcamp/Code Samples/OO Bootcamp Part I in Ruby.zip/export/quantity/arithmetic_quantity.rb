module Bootcamp
  module Quantity

    # Understands a specific amount that supports arithmetic
    class ArithmeticQuantity < Quantity
      
      def +(other)
        if !@unit.compatible?(other.unit)
          raise IncompatibleMetricsError.new(@unit, other.unit)
        end
        Quantity.new(@amount + otherAmount(other), @unit)
      end
      
      def -@
        Quantity.new(-self.amount, @unit)
      end
      
      def -(other)
        self + -other
      end
      
    end
  end
end