﻿using System;
using NUnit.Framework;

namespace ParkingLot3.Visitor.Tests
{
    [TestFixture]
    public class ParkingLotParkingCarTest
    {
        private ParkingLot _fullParkingLot;

        [SetUp]
        public void SetUp()
        {
            _fullParkingLot = new ParkingLot(capacity: 1);
            _fullParkingLot.ParkCar(new Car());
        }

        [Test]
        public void Parking_as_many_cars_as_the_capacity_should_be_permitted()
        {
            var target = new ParkingLot(capacity: 3);

            target.ParkCar(new Car());
            target.ParkCar(new Car());
            target.ParkCar(new Car());
        }

        [Test]
        public void After_parking_as_many_cars_as_the_capacity_should_have_no_available_space_left()
        {
            Assert.That(_fullParkingLot.HasAvailableSpace, Is.False);
        }

        [Test]
        public void When_there_is_no_available_space_then_parking_a_car_should_raise_an_error()
        {
            Assert.Throws<InvalidOperationException>(() => _fullParkingLot.ParkCar(new Car()));
        }

        [Test]
        public void Parking_the_same_car_twice_should_raise_an_error()
        {
            var target = new ParkingLot(capacity: 3);
            var car = new Car();
            var sameCar = car;

            target.ParkCar(car);

            Assert.Throws<InvalidOperationException>(() => target.ParkCar(sameCar));
        }
    }
}
