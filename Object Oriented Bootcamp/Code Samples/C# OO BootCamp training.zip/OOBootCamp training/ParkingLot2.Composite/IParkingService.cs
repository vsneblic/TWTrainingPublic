﻿namespace ParkingLot2.Composite
{
    public interface IParkingService
    {
        double PercentageFull { get; }
        void ParkCar(Car carToPark);
    }
}