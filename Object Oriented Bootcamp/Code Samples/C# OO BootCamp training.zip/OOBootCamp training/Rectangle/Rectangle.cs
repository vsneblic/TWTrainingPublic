﻿

namespace Rectangle
{
    public class Rectangle
    {
        private readonly int _length;
        private readonly int _width;

        public Rectangle(int length, int width)
        {
            _length = length;
            _width = width;
        }

        public int Perimeter
        {
            get { return 2 * (_length + _width);  }
        }

        public int Area
        {
            get { return _length * _width; }
        }
    }
}
