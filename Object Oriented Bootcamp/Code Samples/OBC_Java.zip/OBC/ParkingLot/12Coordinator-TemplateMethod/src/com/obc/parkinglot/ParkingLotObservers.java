package com.obc.parkinglot;

import java.util.ArrayList;

public class ParkingLotObservers extends ArrayList<ParkingSpaceObserver> {

	public void notifyHasSpace(ParkingSpace lot) {
		for (ParkingSpaceObserver observer : this) {
			observer.notifyHasSpace(lot);
		}
	}

	public void notifyFull(ParkingSpace lot) {
		for (ParkingSpaceObserver observer : this) {
			observer.notifyFull(lot);
		}
	}
	
}
