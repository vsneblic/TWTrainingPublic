package quantity;

/**
 * 	Understands a specific metric.
 */
public abstract class Unit {
	final double ratio;
	final Object type;

	public Unit(double ratio, Object type) {
		this.ratio = ratio;
		this.type = type;
	}

	public boolean sameTypeAs(Unit other) {
		return this.type == other.type;
	}

	abstract double amountIn(double amount, Unit base);
}