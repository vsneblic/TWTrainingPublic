package golf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class ClubHouse {

	private final List<Integer> parties;

	public ClubHouse() {
		parties = new ArrayList<Integer>();
	}
	
	public void arrive(int party) {
		parties.add(party);
	}

	public Collection release() {
		return teeGroup().parties;
	}

	private TeeGroup teeGroup() {
		TeeGroup group = new TeeGroup();
		for (Iterator i = parties.iterator(); i.hasNext();)
			if (group.accept((Integer)i.next()))
				i.remove();
		return group;
	}

	private class TeeGroup {
		private static final int MAX_PARTY_SIZE = 4;
		private final Collection<Integer> parties;
		
		public TeeGroup() {
			parties = new ArrayList<Integer>();
		}
		
		public boolean accept(int party) {
			if (size() + party > MAX_PARTY_SIZE) return false;
			parties.add(party);
			return true;
		}

		public void add(int party) {
			parties.add(party);
		}
		
		public int size() {
			int size = 0;
			for (int party : parties)
				size += party;
			return size;
		}	
	}
}
