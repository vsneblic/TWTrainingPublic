module Bootcamp
  module Graph
    
    # Understands its neighors
    class Node
      NO_PATH = 1.0/0.0
    
      def initialize(name)
        @name = name
        @neighbors = []
      end
      
      def connect_to(neighbor)
        @neighbors << neighbor
      end
      
      def reach?(destination)
        _hop_count(destination, []) != NO_PATH
      end

      def hop_count(destination)
        result = _hop_count(destination, [])
        raise NoPathError.new(self, destination) if result == NO_PATH
        result
      end
      
      protected
      def _hop_count(destination, visited_nodes)
        return 0 if self == destination
        return NO_PATH if visited_nodes.include?(self) || @neighbors.empty?
        (visited_nodes = visited_nodes.dup) << self
        @neighbors.collect {|n| n._hop_count(destination, visited_nodes)}.min + 1
      end
      
    end

  end
end