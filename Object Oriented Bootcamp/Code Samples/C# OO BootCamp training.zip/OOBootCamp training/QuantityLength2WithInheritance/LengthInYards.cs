﻿namespace QuantityLength2WithInheritance
{
    public class LengthInYards : Length
    {
        private const double ConversionFactorToInches = 36.0;

        public LengthInYards(double value) : base(value, ConversionFactorToInches) {}

        public static LengthInYards operator +(LengthInYards leftValue, LengthInYards rightValue)
        {
            return new LengthInYards(leftValue.SumUpWithTheValueOf(rightValue));
        }
    }
}