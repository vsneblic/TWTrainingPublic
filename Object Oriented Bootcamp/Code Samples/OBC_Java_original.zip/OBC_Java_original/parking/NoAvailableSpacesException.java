package parking;

public class NoAvailableSpacesException extends RuntimeException {

	public NoAvailableSpacesException() {
		super("No spaces available in any lot.");
	}

	private static final long serialVersionUID = 9156787945455092014L;

}
