package com.obc.parkinglot;

import java.util.List;

public //Understands different criteria for selecting lots 
abstract class LotSelectionMethod {
	public abstract ParkingLot selectLotToParkInto(List<ParkingLot> availableLots);
	
	public static final LotSelectionMethod FIRST_AVAILABLE = new FirstAvailableLot();
	
	
	public static final LotSelectionMethod MOST_CAPACITY = new MostCapacityLot();
	
	public static final LotSelectionMethod MOST_FREE = new MostFreeLot();
	
	public static final LotSelectionMethod CHEAPEST = new LotSelectionMethod() {
		@Override
		public ParkingLot selectLotToParkInto(List<ParkingLot> availableLots) {
			ParkingLot champion = availableLots.get(0);
			for (ParkingLot challenger : availableLots) {
				if (challenger.cost() < champion.cost())
					champion = challenger;
			}
			return champion;
		}
	};
}

// Understands how to select the first lot with space available 
class FirstAvailableLot extends LotSelectionMethod {
	@Override
	public ParkingLot selectLotToParkInto(List<ParkingLot> availableLots) {
		return availableLots.get(0);
	}
}

// Understands how to select the lot with maximum capacity
class MostCapacityLot extends LotSelectionMethod {
	@Override
	public ParkingLot selectLotToParkInto(List<ParkingLot> availableLots) {
		ParkingLot champion = availableLots.get(0);
		for (ParkingLot challenger : availableLots) {
			if (challenger.capacity() > champion.capacity())
				champion = challenger;
		}
		return champion;
	}
}

// Understands how to select the lot with the maximum free space
class MostFreeLot extends LotSelectionMethod {
	@Override
	public ParkingLot selectLotToParkInto(List<ParkingLot> availableLots) {
		ParkingLot champion = availableLots.get(0);
		for (ParkingLot challenger : availableLots) {
			if (challenger.freeSpace() > champion.freeSpace())
				champion = challenger;
		}
		return champion;
	}
}
