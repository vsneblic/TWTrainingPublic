package rectangle;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 *	Ensures the correctness of Rectangle.
 */

public class RectangleTest {
	
	@Test public void shouldBeAbleToDetermineArea() throws Exception {
		assertEquals(6, new Rectangle(3, 2).area());
	}
}
