package com.obc.graph;

import junit.framework.TestCase;

// Ensures correctness of the graph
public class GraphTest extends TestCase {
	public void testCanReach() throws Exception {
		Node a = new Node("a");
		assertCanReach(a, a);

		Node unconnected = new Node("unconnected");
		assertCannotReach(a, unconnected);

		Node b = new Node("b");
		a.connect(b);
		assertCanReach(a, b);
		assertCannotReach(b, a);

		Node c = new Node("c");
		b.connect(c);
		assertCanReach(a, c);
		
		addCycle(a);
		
		Node d = new Node("d");
		a.connect(d);
		assertCanReach(a, d);
	}

	private void assertCannotReach(Node source, Node destination) {
		assertFalse(source.canReach(destination));
	}

	private void assertCanReach(Node source, Node destination) {
		assertTrue(source.canReach(destination));
	}

	private void addCycle(Node start) {
		Node x = new Node("x");
		Node y = new Node("y");
		start.connect(x);
		x.connect(y);
		y.connect(start);
	}
}
