module Bootcamp
  module Graph
  
    # Understands a connection from one Node to another
    class Link
    
      def initialize(targetNode, cost)
        @target, @cost = targetNode, cost
      end
      
      def _hop_count(destination, visited_nodes)
        @target._hop_count(destination, visited_nodes) + 1
      end
      
      def _cost(destination, visited_nodes)
        @target._cost(destination, visited_nodes) + @cost
      end
        
    end
    
  end
end