﻿namespace ParkingLot3.Visitor
{
    public interface IParkingLotObserver
    {
        void ChangeNotification(ParkingLot sender);
    }
}