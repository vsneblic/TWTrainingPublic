module Bootcamp
  module Quantity

    # Understands a specific amount
    class Quantity
      
      attr_reader :amount, :unit
      protected :amount, :unit
      
      def initialize(amount, unit)
        @amount, @unit = amount.to_f, unit
      end
      
      def ==(other)
        return false if !@unit.compatible?(other.unit)
        @amount == otherAmount(other)
      end
      
      protected
      def otherAmount(otherQuantity)
        @unit.amountFrom(otherQuantity.amount, otherQuantity.unit)
      end
      
    end
  end
end