package com.obc.quantity;

import src.IncompatibleUnitsException;
import src.ArithmeticQuantity;
import junit.framework.TestCase;

// Ensures correctness of Quantity
public class QuantityTest extends TestCase {

	private ArithmeticQuantity foot1;
	private ArithmeticQuantity inch12;
	private ArithmeticQuantity gram1;

	protected void setUp() {
		foot1 = ArithmeticQuantity.foot(1);
		inch12 = ArithmeticQuantity.inch(12);
		gram1 = ArithmeticQuantity.gram(1);
	}

	public void testSameUnitEquals() {
		assertEquals(foot1, ArithmeticQuantity.foot(1));
		assertFalse(foot1.equals(ArithmeticQuantity.foot(2)));
		assertFalse(foot1.equals(null));
		assertFalse(foot1.equals(new Object()));
	}

	public void testDifferentUnitEquals() {
		assertFalse(foot1.equals(ArithmeticQuantity.inch(1)));
		assertEquals(foot1, inch12);
		assertEquals(inch12, foot1);
	}
	
	public void testYardEquals() {
		assertEquals(ArithmeticQuantity.foot(3), ArithmeticQuantity.yard(1));
	}
	
	public void testWeightEquals() {
		assertEquals(gram1, ArithmeticQuantity.gram(1));
		final ArithmeticQuantity kg1 = ArithmeticQuantity.kilogram(1);
		assertEquals(kg1, ArithmeticQuantity.kilogram(1));
		assertEquals(kg1, ArithmeticQuantity.gram(1000));
	}
	
	public void testWeightNotEqualsLength() {
		assertFalse(ArithmeticQuantity.gram(1).equals(ArithmeticQuantity.inch(1)));
	}
	
	public void testAdd() throws IncompatibleUnitsException  {
		final ArithmeticQuantity foot2 = ArithmeticQuantity.foot(2);
		assertEquals(foot2, foot1.add(foot1));
		assertEquals(foot2, foot1.add(inch12));
		assertEquals(ArithmeticQuantity.kilogram(2), ArithmeticQuantity.gram(1000).add(ArithmeticQuantity.kilogram(1)));
	}
	
	public void testCannotAddALengthAndAWeight() {
		try {
			foot1.add(gram1);
			fail("Shouldn't be able to add a gram and a foot");
		} catch (IncompatibleUnitsException expected) {
		}
	}
	
	public void testCanHandleFractionalValues() {
		assertEquals(ArithmeticQuantity.foot(0.5), ArithmeticQuantity.inch(6));
		assertEquals(ArithmeticQuantity.yard(1.0/3.0), foot1);
		assertEquals(ArithmeticQuantity.inch(0.5), ArithmeticQuantity.inch(0.5));
		assertEquals(ArithmeticQuantity.gram(500), ArithmeticQuantity.kilogram(0.5));
		assertEquals(ArithmeticQuantity.gram(0.5), ArithmeticQuantity.gram(0.5));
	}
	
	public void testTemperatureEquals() {
		assertEquals(ArithmeticQuantity.celsius(0), ArithmeticQuantity.celsius(0));
		assertFalse(ArithmeticQuantity.celsius(0).equals(ArithmeticQuantity.celsius(1)));
		assertEquals(ArithmeticQuantity.kelvin(273), ArithmeticQuantity.celsius(0));
		assertEquals(ArithmeticQuantity.fahrenheit(-40), ArithmeticQuantity.celsius(-40));
	}
}
