module Bootcamp
  module Graph
  
    # Understands a way to traverse from one Node to another
    class Path
    
      $HOP_COUNT = lambda {|left, right| left.hop_count <=> right.hop_count}
      $ACTUAL_COST = lambda {|left, right| left.cost <=> right.cost}
      
      def initialize()
        @links = []
      end
      
      def <<(link)
        @links << link
        self
      end
      
      def hop_count
        @links.size
      end
      
      def cost
        @links.inject(0) {|total, link| total + link.cost}
      end
      
      def lesser(other, strategy)
        strategy.call(self, other) < 0 ? self : other
      end
        
    end
    
  end
end