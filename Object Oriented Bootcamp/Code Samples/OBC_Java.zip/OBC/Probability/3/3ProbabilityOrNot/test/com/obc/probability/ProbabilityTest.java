package com.obc.probability;

import src.Probability;
import junit.framework.TestCase;

// Ensures correctness of Probability
public class ProbabilityTest extends TestCase {

	private Probability probability1;
	private Probability probabilityHalf;

	protected void setUp() {
		probability1 = new Probability(1.0);
		probabilityHalf = new Probability(0.5);
	}

	public void testEquals() {
		assertEquals(probability1, probability1);
		assertFalse(probability1.equals(new Probability(0.5)));
		assertFalse(probability1.equals(null));
		assertFalse(probability1.equals(new Object()));
	}

	public void testAnd() {
		assertEquals(probability1, probability1.and(probability1));
		assertEquals(probabilityHalf, probability1.and(probabilityHalf));
		assertEquals(new Probability(0.25), probabilityHalf.and(probabilityHalf));
	}
	
	public void testNot() {
		assertEquals(new Probability(0), probability1.not());
		assertEquals(probabilityHalf, probabilityHalf.not());
	}
	
	public void testOr() throws Exception {
		assertEquals(probability1, probability1.or(probability1));
		assertEquals(probability1, probability1.or(probabilityHalf));
		assertEquals(new Probability(0.75), probabilityHalf.or(probabilityHalf));
	}
}
