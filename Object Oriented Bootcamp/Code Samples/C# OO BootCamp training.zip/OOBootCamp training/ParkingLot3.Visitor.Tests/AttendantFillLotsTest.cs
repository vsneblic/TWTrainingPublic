﻿using System;
using NUnit.Framework;

namespace ParkingLot3.Visitor.Tests
{
    [TestFixture]
    public class AttendantFillLotsTest
    {
        private Attendant _attendant;
        private ParkingLot _emptyParkingLot;

        [SetUp]
        public void SetUp()
        {
            _attendant = new Attendant();
            _emptyParkingLot = new ParkingLot(capacity: 10);
        }

        [Test]
        public void With_no_lots_should_raise_an_error()
        {
            Assert.Throws<InvalidOperationException>(() => _attendant.ParkCar(new Car()));
        }

        [Test]
        public void With_only_one_lot_should_park_on_that_lot()
        {
            _attendant.Attend(_emptyParkingLot);

            _attendant.ParkCar(new Car());

            Assert.That(_emptyParkingLot.PercentageFull, Is.GreaterThan(0.0));
        }

        [Test]
        public void With_an_empty_lot_and_one_with_one_car_should_fill_the_empty_lot_first()
        {
            var parkingLotWithACar = new ParkingLot(capacity: 10);
            parkingLotWithACar.ParkCar(new Car());

            _attendant.Attend(parkingLotWithACar);
            _attendant.Attend(_emptyParkingLot);

            _attendant.ParkCar(new Car());

            Assert.That(_emptyParkingLot.PercentageFull, Is.GreaterThan(0.0));
        }
    }


}
