﻿

using System.Collections.Generic;

namespace Graph.MinHopCount
{
    public class Node
    {
        private readonly string _name;
        private readonly List<Node> _neightbors;

        public Node(string name) : this(name, new Node[0])
        {
        }

        public Node(string name, IEnumerable<Node> neightbors)
        {
            _name = name;
            _neightbors = new List<Node>(neightbors);
        }

        public void AddNeighbor(Node neighborNode)
        {
            _neightbors.Add(neighborNode);
        }


        public bool CanReach(Node destination)
        {
            return MinHopCountTo(destination) >= 0;
        }

        public int MinHopCountTo(Node destination)
        {
            return MinHopCountTo(destination, new Dictionary<Node, int>());
        }

        private int MinHopCountTo(Node destination, Dictionary<Node, int> visitedNodeHopCountToDestination)
        {
            if (this == destination)
            {
                return 0;
            }

            if (visitedNodeHopCountToDestination.ContainsKey(this))
            {
                return visitedNodeHopCountToDestination[this];
            }

            const int hopCountForDestinationNotFound = -1;            
            visitedNodeHopCountToDestination.Add(this, hopCountForDestinationNotFound);
            
            foreach (var neighbor in _neightbors)
            {
                if (visitedNodeHopCountToDestination.ContainsKey(neighbor) &&
                    visitedNodeHopCountToDestination[neighbor] == hopCountForDestinationNotFound)
                {
                    continue;
                }

                var hopCountFromHere = neighbor.MinHopCountTo(destination, visitedNodeHopCountToDestination);

                var thisHopCountIsSmaller = visitedNodeHopCountToDestination[this] == hopCountForDestinationNotFound ||
                                            1 + hopCountFromHere < visitedNodeHopCountToDestination[this];

                if (hopCountFromHere != hopCountForDestinationNotFound && thisHopCountIsSmaller)
                {
                    visitedNodeHopCountToDestination[this] = 1 + hopCountFromHere;
                }
            }

            return visitedNodeHopCountToDestination[this];
        }
    }
}
