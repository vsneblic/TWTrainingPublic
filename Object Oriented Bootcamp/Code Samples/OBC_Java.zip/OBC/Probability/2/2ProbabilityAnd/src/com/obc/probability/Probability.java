package com.obc.probability;

// Understands the chance of an event occuring
public class Probability {

	private final double value;

	public Probability(double valueAsFraction) {
		this.value = valueAsFraction;
	}

	public String toString() {
		return "Probability:" + value;
	}

	public boolean equals(Object other) {
		if (other==null) return false;
		if (other.getClass() != getClass()) return false;
		return ((Probability)other).value == value;
	}

	public Probability and(Probability other) {
		return new Probability(value * other.value);
	}
	
	
}
