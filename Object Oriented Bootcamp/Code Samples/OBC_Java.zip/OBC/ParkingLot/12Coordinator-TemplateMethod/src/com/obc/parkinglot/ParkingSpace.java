package com.obc.parkinglot;

// Understands a space which can temporarily hold cars
public abstract class ParkingSpace {

	protected ParkingLotObservers observers = new ParkingLotObservers();

	public abstract int cost();

	public abstract int capacity();

	public abstract int freeSpace();

	public abstract boolean hasCarFor(Object token);

	public abstract boolean isFull();

	public abstract boolean hasCar(Object car);

	public void addObserver(ParkingSpaceObserver observer) {
		observers.add(observer);
	}

	protected abstract Object doUnpark(Object token)
			throws CannotUnparkException;

	public Object unpark(Object token) throws CannotUnparkException {
		if (!hasCarFor(token))
			throw new CannotUnparkException(token, this);
		boolean wasFull = isFull();
		Object car = doUnpark(token);
		if (wasFull)
			observers.notifyHasSpace(this);
		return car;
	}

	protected abstract Object doPark(Object car) throws CannotParkException;

	public Object park(Object car) throws CannotParkException {
		if (isFull())
			throw CannotParkException.becauseLotIsFull(car, this);
		if (hasCar(car))
			throw CannotParkException.becauseCarIsPresentInLot(car, this);
		Object token = doPark(car);
		if (isFull())
			observers.notifyFull(this);
		return token;
	}
}
