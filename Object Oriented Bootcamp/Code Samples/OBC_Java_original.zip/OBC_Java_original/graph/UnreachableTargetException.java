package graph;

/**
 * 	Understands communication of not being able to get to a desired target Node.
 */
public class UnreachableTargetException extends Exception {

	private static final long serialVersionUID = 3566489674583488748L;

	public UnreachableTargetException(Node start, Node target) {
		super("Can not reach target: " + target + " from start: " + start + ".");
	}

}
