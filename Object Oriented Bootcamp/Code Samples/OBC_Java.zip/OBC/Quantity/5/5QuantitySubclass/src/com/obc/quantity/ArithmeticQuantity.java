package com.obc.quantity;

// Understands an addable measurement
public class ArithmeticQuantity extends Quantity {

	public static ArithmeticQuantity yard(double numberOfYards) {
		return new ArithmeticQuantity(numberOfYards, Unit.YARD);
	}

	public static ArithmeticQuantity foot(double numberOfFeet) {
		return new ArithmeticQuantity(numberOfFeet, Unit.FOOT);
	}

	public static ArithmeticQuantity inch(double numberOfInches) {
		return new ArithmeticQuantity(numberOfInches, Unit.INCH);
	}

	public static ArithmeticQuantity gram(double numberOfGrams) {
		return new ArithmeticQuantity(numberOfGrams, Unit.GRAM);
	}

	public static ArithmeticQuantity kilogram(double numberOfKilos) {
		return new ArithmeticQuantity(numberOfKilos, Unit.KG);
	}

	private ArithmeticQuantity(double value, Unit unit) {
		super(value, unit);
	}

	public ArithmeticQuantity add(ArithmeticQuantity other) throws IncompatibleUnitsException {
		if (!unit.comparableWith(other.unit)) 
			throw new IncompatibleUnitsException("Can't add units of different kinds: " + unit + " and " + other.unit);
		return new ArithmeticQuantity(value + other.convertTo(unit), unit);
	}
}