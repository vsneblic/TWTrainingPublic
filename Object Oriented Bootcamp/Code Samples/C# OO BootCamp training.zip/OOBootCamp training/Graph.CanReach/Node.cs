﻿

using System.Collections.Generic;
using System.Linq;

namespace Graph.CanReach
{
    public class Node
    {
        private readonly string _name;
        private readonly List<Node> _neightbors;

        public Node(string name) : this(name, new Node[0])
        {
        }

        public Node(string name, IEnumerable<Node> neightbors)
        {
            _name = name;
            _neightbors = new List<Node>(neightbors);
        }

        public void AddNeighbor(Node neighborNode)
        {
            _neightbors.Add(neighborNode);
        }


        public bool CanReach(Node destination)
        {
            return CanReach(destination, new List<Node>());
        }

        private bool CanReach(Node destination, List<Node> visitedNodes)
        {
            visitedNodes.Add(this);

            return this == destination || _neightbors.Except(visitedNodes).Any(node => node.CanReach(destination, visitedNodes));
        }
    }
}
