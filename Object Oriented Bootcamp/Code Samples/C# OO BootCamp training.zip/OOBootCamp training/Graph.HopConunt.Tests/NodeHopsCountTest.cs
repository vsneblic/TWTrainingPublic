﻿using NUnit.Framework;

namespace Graph.HopCount.Tests
{
    [TestFixture]
    public class NodeHopCountTest
    {
        private Node _nodeA;
        private Node _nodeB;
        private Node _nodeC;
        private Node _nodeX;

        [SetUp]
        public void SetUp()
        {
            _nodeA = new Node("A");
            _nodeB = new Node("B");
            _nodeC = new Node("C");
            _nodeX = new Node("X");
        }

        [Test]
        public void Hop_count_to_self_should_be_zero()
        {
            Assert.That(_nodeA.HopCountTo(_nodeA), Is.EqualTo(0));
        }

        [Test]
        public void Hop_count_to_a_non_existing_destination_should_be_minus_one()
        {
            Assert.That(_nodeA.HopCountTo(_nodeX), Is.EqualTo(-1));
        }

        [Test]
        public void Hop_count_to_a_neightbor_should_be_one()
        {
            _nodeA.AddNeighbor(_nodeB);
            Assert.That(_nodeA.HopCountTo(_nodeB), Is.EqualTo(1));
        }

        [Test]
        public void Hop_count_to_its_neighbor_neighbor_should_be_two()
        {
            _nodeA.AddNeighbor(_nodeB);
            _nodeB.AddNeighbor(_nodeC);
            Assert.That(_nodeA.HopCountTo(_nodeC), Is.EqualTo(2));
        }

        [Test]
        public void Hop_count_should_work_in_presence_of_cycles()
        {
            _nodeA.AddNeighbor(_nodeB);
            _nodeB.AddNeighbor(_nodeA);

            Assert.That(_nodeA.HopCountTo(_nodeX), Is.EqualTo(-1));
        }

        [Test]
        public void Hop_count_should_work_in_presence_of_a_self_cycles()
        {
            _nodeA.AddNeighbor(_nodeA);

            Assert.That(_nodeA.HopCountTo(_nodeX), Is.EqualTo(-1));
        }
    }
}
