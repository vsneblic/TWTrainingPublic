package rectangle;

/**
 * 	Understands a region of space enclosed by four right angles.
 */
public class Rectangle {

	private final int width;
	private final int length;

	public Rectangle(int length, int width) {
		this.width = width;
		this.length = length;
	}

	public int area() {		
		return length * width;
	}
}
