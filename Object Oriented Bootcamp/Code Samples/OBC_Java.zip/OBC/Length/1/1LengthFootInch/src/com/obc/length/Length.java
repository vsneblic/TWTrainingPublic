package com.obc.length;

// Understands a measurement of distance
public class Length {

	public static final Object INCH = new Object();
	public static final Object FOOT = new Object();
	private static final int INCHES_IN_FOOT = 12;

	private final int value;
	private final Object unit;

	public static Length foot(int numberOfFeet) {
		return new Length(numberOfFeet, FOOT);
	}

	public static Length inch(int numberOfInches) {
		return new Length(numberOfInches, INCH);
	}
	
	private Length(int value, Object unit) {
		this.value = value;
		this.unit = unit;
	}

	public String toString() {
		return "Length: " + value;
	}

	public boolean equals(Object other) {
		if ((other == null) || other.getClass() != getClass())
			return false;
		return inInches() == ((Length) other).inInches();
	}

	private int inInches() {
		return unit == FOOT ? value * INCHES_IN_FOOT : value;
	}
}
