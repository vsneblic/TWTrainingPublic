module Bootcamp
  module Graph
  
    # Understands a connection from one Node to another
    class Link
      
      $HOP_COUNT = lambda {|link| 1}
      $ACTUAL_COST = lambda {|link| link.cost}
      
      attr_reader :cost
    
      def initialize(targetNode, cost)
        @target, @cost = targetNode, cost
      end
      
      def _cost(destination, visited_nodes, cost)
        @target._cost(destination, visited_nodes, cost) + cost.call(self)
      end
        
    end
    
  end
end