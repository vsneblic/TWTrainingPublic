package com.obc.graph;

import junit.framework.TestCase;

// Ensures correctness of the graph
public class GraphTest extends TestCase {
	
	private Node a;
	private Node unconnected;
	private Node b;
	private Node c;
	private Node d;

	@Override
	protected void setUp() throws Exception {
		super.setUp();

		a = new Node("a");
		unconnected = new Node("unconnected");
		b = new Node("b");
		c = new Node("c");
		d = new Node("d");
		a.connect(b);
		b.connect(c);
		addCycle(a);
		a.connect(d);
	}

	public void testCanReach() throws Exception {
		assertCanReach(a, a);
		assertCannotReach(a, unconnected);

		assertCanReach(a, b);
		assertCannotReach(b, a);

		assertCanReach(a, c);
		assertCanReach(a, d);
	}

	private void assertCannotReach(Node source, Node destination) {
		assertFalse(source.canReach(destination));
	}

	private void assertCanReach(Node source, Node destination) {
		assertTrue(source.canReach(destination));
	}

	private void addCycle(Node start) {
		Node x = new Node("x");
		Node y = new Node("y");
		start.connect(x);
		x.connect(y);
		y.connect(start);
	}
	
	public void testHopCount() throws Exception {
		assertHops(0, a, a);
		assertCannotCountHops(a, unconnected);
		assertHops(1, a, b);
		assertCannotCountHops(b, a);
		assertHops(2, a, c);
	}

	private void assertCannotCountHops(Node source, Node destination) {
		try {
			source.hopCount(destination);
			fail("Cannot determine hopcount of a node that is not reachable");
		} catch (UnreachableNodeException expected) { }
	}

	private void assertHops(int expected, Node source, Node destination) throws UnreachableNodeException {
		assertEquals(expected, source.hopCount(destination));
	}
}
