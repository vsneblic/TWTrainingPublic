﻿namespace ParkingLot2.Composite
{
    public class Car {}
}