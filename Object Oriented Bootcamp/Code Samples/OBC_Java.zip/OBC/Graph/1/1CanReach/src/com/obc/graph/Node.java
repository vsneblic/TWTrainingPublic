package com.obc.graph;

import java.util.ArrayList;
import java.util.List;

// Understands its neighbours
public class Node {

	private final String name;
	private List<Node> neighbours = new ArrayList<Node>();

	public Node(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Node: " + name;
	}

	public boolean canReach(Node destination) {
		return canReach(destination, new ArrayList<Node>());
	}

	private boolean canReach(Node destination, List<Node> visited) {
		if (destination == this) return true;
		if (visited.contains(this)) return false;
		visited.add(this);
		for (Node neighbour : neighbours) {
			if (neighbour.canReach(destination, visited)) return true;
		}
		return false;
	}

	public void connect(Node neighbour) {
		neighbours.add(neighbour);
	}	
}
