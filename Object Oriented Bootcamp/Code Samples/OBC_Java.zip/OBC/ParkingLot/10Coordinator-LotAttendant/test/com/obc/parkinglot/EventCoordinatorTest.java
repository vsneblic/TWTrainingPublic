package com.obc.parkinglot;

import junit.framework.TestCase;

// Ensures correctness of the event coordinator
public class EventCoordinatorTest extends TestCase {
	
	public void testCoordinatorCanDirectCarsTo1Attendant() throws Exception {
		Attendant attendant = Attendant.firstLotParker();
		ParkingLot lot = new ParkingLot(1);
		attendant.responsibleFor(lot);
		

		EventCoordinator coordinator = new EventCoordinator();
		coordinator.add(attendant);

		Object token = coordinator.direct(car());
		assertTrue(lot.hasCarFor(token));
	}
	
	public void testCoordinatorCanDirectCarsTo2ndAttendant() throws Exception {
		EventCoordinator coordinator = new EventCoordinator();

		ParkingLot lot1 = new ParkingLot(1);
		lot1.park(car());
		Attendant attendant1 = Attendant.firstLotParker();
		attendant1.responsibleFor(lot1);
		coordinator.add(attendant1);

		ParkingLot lot2 = new ParkingLot(1);
		Attendant attendant2 = Attendant.firstLotParker();
		attendant2.responsibleFor(lot2);
		coordinator.add(attendant2);
		
		Object token = coordinator.direct(car());
		assertTrue(lot2.hasCarFor(token));
	}
	
	public void testCoordinatorWith2AttendantsCanDirectCarsTo1stAttendant() throws Exception {
		EventCoordinator coordinator = new EventCoordinator();

		ParkingLot lot1 = new ParkingLot(1);
		Attendant attendant1 = Attendant.firstLotParker();
		attendant1.responsibleFor(lot1);
		coordinator.add(attendant1);

		ParkingLot lot2 = new ParkingLot(1);
		Attendant attendant2 = Attendant.firstLotParker();
		attendant2.responsibleFor(lot2);
		coordinator.add(attendant2);
		
		Object token = coordinator.direct(car());
		assertTrue(lot1.hasCarFor(token));
	}
	
	public void testCoordinatorCannotParkCarsIfAllAttendantsHaveAllLotsFull() throws Exception {
		EventCoordinator coordinator = new EventCoordinator();

		ParkingLot fullLot = new ParkingLot(1);
		fullLot.park(car());
		Attendant attendant1 = Attendant.firstLotParker();
		attendant1.responsibleFor(fullLot);
		coordinator.add(attendant1);

		try {
			coordinator.direct(car());
			fail("Shouldn't be able to park since none of the attendants have lots with space");
		} catch (CannotParkException expected) {
		}
	}
	
	public void testCoordinatorCanParkInto1Lot() throws Exception {
		EventCoordinator coordinator = new EventCoordinator();
		
		ParkingLot lot = new ParkingLot(1);
		coordinator.add(lot);
		Object token = coordinator.direct(car());
		assertTrue(lot.hasCarFor(token));
	}
	
	public void testCoordinatorCanParkInto1stLotEvenWhileHandling2Lots() throws Exception {
		EventCoordinator coordinator = new EventCoordinator();
		
		ParkingLot lot1 = new ParkingLot(1);
		coordinator.add(lot1);
		ParkingLot lot2 = new ParkingLot(2);
		coordinator.add(lot2);
		Object token = coordinator.direct(car());
		assertTrue(lot1.hasCarFor(token));
	}
	
	private Object car() {
		return new Object();
	}

}
