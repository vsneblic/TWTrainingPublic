$:.unshift File.dirname(__FILE__)
require 'test/unit'
require 'node'
require 'no_path_error'

module Bootcamp
  module Graph

    # Ensures graph algorithms work correctly
    class TestGraph < Test::Unit::TestCase
    
      def setup
        @a = Node.new("a")
        @b = Node.new("b")
        @c = Node.new("c")
        @d = Node.new("d")
        @e = Node.new("e")
        @f = Node.new("f")
        @g = Node.new("g")
        @a.connect_to(@f)
        @b.connect_to(@a)
        @b.connect_to(@c)
        @c.connect_to(@d)
        @c.connect_to(@e)
        @c.connect_to(@e)
        @d.connect_to(@e)
        @e.connect_to(@b)
      end
      
      def test_reach
        assert(@a.reach?(@a))
        assert(@b.reach?(@a))
        assert(!@g.reach?(@a))
        assert(!@a.reach?(@g))
        assert(!@b.reach?(@g))
        assert(@c.reach?(@f))
      end
      
      def test_hopCount
        assert_equal(0, @a.hop_count(@a))
        assert_equal(1, @b.hop_count(@a))
        assert_equal(2, @b.hop_count(@f))
        assert_equal(2, @b.hop_count(@e))
        assert_equal(4, @c.hop_count(@f))
      end
      
      def test_no_path
        assert_no_path(@g, @a)
        assert_no_path(@a, @b)
        assert_no_path(@a, @g)
        assert_no_path(@b, @g)
      end
      
      private
      def assert_no_path(from, to)
        assert_raise(NoPathError) do
          from.hop_count(to)
        end
      end
      
    end

  end
end