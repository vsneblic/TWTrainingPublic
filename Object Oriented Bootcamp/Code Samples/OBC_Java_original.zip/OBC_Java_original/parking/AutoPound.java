package parking;

import java.util.ArrayList;
import java.util.Collection;

//import com.eviltowtruck.ImpoundLot;

public class AutoPound extends ParkingLot {
	private static final int CAPACITY = 100;
//	private ImpoundLot pound = new ImpoundLot(CAPACITY, 0);
//	private Collection<Object> impounded = new ArrayList<Object>();
//
	public AutoPound() {
		this(CAPACITY);
	}
//
	public AutoPound(int capacity) {
		super("Pound", capacity);
	}
//
//	@Override
//	public boolean canPark() {
//		return pound.ableToPark();
//	}
//
//	@Override
//	boolean contains(Object car) {
//		return impounded.contains(car);
//	}
//
//	@Override
//	public void park(Object car) {
//		pound.impound(car);
//		for (ParkingLotObserver observer : observers)
//			observer.notify(impounded.size(), CAPACITY, this);
//	}
//
//	@Override
//	int percentFull() {
//		return pound.howFull();
//	}
//
//	@Override
//	public void remove(Object car) {
//	}

}
