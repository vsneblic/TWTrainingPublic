package com.obc.quantity;

// Understands a measurement
public class Quantity {

	private final int value;
	private final Unit unit;

	public static Quantity yard(int numberOfYards) {
		return new Quantity(numberOfYards, Unit.YARD);
	}

	public static Quantity foot(int numberOfFeet) {
		return new Quantity(numberOfFeet, Unit.FOOT);
	}

	public static Quantity inch(int numberOfInches) {
		return new Quantity(numberOfInches, Unit.INCH);
	}

	public static Quantity gram(int numberOfGrams) {
		return new Quantity(numberOfGrams, Unit.GRAM);
	}

	public static Quantity kilogram(int numberOfKilos) {
		return new Quantity(numberOfKilos, Unit.KG);
	}

	private Quantity(int value, Unit unit) {
		this.value = value;
		this.unit = unit;
	}

	public String toString() {
		return "Length: " + value;
	}

	public boolean equals(Object other) {
		if ((other == null) || other.getClass() != getClass())
			return false;
		final Quantity otherQuantity = ((Quantity) other);
		if (!unit.comparableWith(otherQuantity.unit)) return false;
		return inBaseUnits() == otherQuantity.inBaseUnits();
	}

	private int inBaseUnits() {
		return unit.inBaseUnits(value);
	}
}

// Understands a metric
class Unit {

	private static final Object WEIGHT = new Object();
	private static final Object LENGTH = new Object();

	private static final int GRAMS_IN_KILOS = 1000;
	public static final Unit KG = new Unit(GRAMS_IN_KILOS, WEIGHT);
	public static final Unit GRAM = new Unit(1, WEIGHT);

	private static final int INCHES_IN_YARD = 36;
	private static final int INCHES_IN_FOOT = 12;

	public static final Unit INCH = new Unit(1, LENGTH);
	public static final Unit YARD = new Unit(INCHES_IN_YARD, LENGTH);
	public static final Unit FOOT = new Unit(INCHES_IN_FOOT, LENGTH);

	private final int numberOfBaseUnits;
	private final Object unitType;

	private Unit(int numberOfInches, Object unitType) {
		this.numberOfBaseUnits = numberOfInches;
		this.unitType = unitType;
	}

	public boolean comparableWith(Unit other) {
		return unitType == other.unitType;
	}

	public int inBaseUnits(int value) {
		return value * numberOfBaseUnits;
	}
}