package com.obc.parkinglot;

import java.util.HashMap;
import java.util.Map;

// Understands a place to keep cars temporarily
public class ParkingLot extends ParkingSpace {

	private int capacity;
	private Map<Object, Object> cars = new HashMap<Object, Object>();
	private final int cost;

	public ParkingLot(int capacity) {
		this(capacity, 0);
	}
	
	public ParkingLot(int capacity, int cost) {
		this.capacity = capacity;
		this.cost = cost;
	}

	@Override
	protected Object doPark(Object car) {
		Object token = new Object();
		cars.put(token, car);
		return token;
	}

	@Override
	public boolean hasCar(Object car) {
		return cars.containsValue(car);
	}

	@Override
	public boolean isFull() {
		return capacity == cars.size();
	}

	@Override
	protected Object doUnpark(Object token) {
		Object car = cars.get(token);
		cars.remove(token);
		return car;
	}

	@Override
	public boolean hasCarFor(Object token) {
		return cars.containsKey(token);
	}

	@Override
	public int freeSpace() {
		return capacity - cars.size();
	}

	@Override
	public int capacity() {
		return capacity;
	}

	@Override
	public int cost() {
		return cost;
	}
}
