﻿using NUnit.Framework;

namespace ParkingLot2.Composite.Tests
{
    [TestFixture]
    public class ParkingLotLastSpaceLeftTest
    {
        private ParkingLot _parkingLot;

        [SetUp]
        public void SetUp()
        {
            _parkingLot = new ParkingLot(capacity: 3);   
        }

        [Test]
        public void When_is_empty_LastSpaceLeft_should_be_false()
        {
            Assert.That(_parkingLot.LastSpaceLeft, Is.False);
        }

        [Test]
        public void When_is_full_LastSpaceLeft_should_be_false()
        {
            _parkingLot.ParkCar(new Car());
            _parkingLot.ParkCar(new Car());
            _parkingLot.ParkCar(new Car());

            Assert.That(_parkingLot.LastSpaceLeft, Is.False);            
        }

        [Test]
        public void When_there_is_one_space_lef_LastSpaceLeft_should_be_true()
        {
            _parkingLot.ParkCar(new Car());
            _parkingLot.ParkCar(new Car());

            Assert.That(_parkingLot.LastSpaceLeft, Is.True);            

        }
    }
}
