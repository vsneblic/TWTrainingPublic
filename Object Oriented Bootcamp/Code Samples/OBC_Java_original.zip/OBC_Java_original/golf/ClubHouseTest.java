package golf;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import org.junit.Test;


public class ClubHouseTest {
	private static final int PARTY_OF_FOUR = 4;
	private static final int PARTY_OF_THREE = 3;
	private static final int PARTY_OF_TWO = 2;
	private static final int PARTY_OF_ONE = 1;
	private final ClubHouse clubHouse = new ClubHouse();

	@Test
	public void shouldBeAbleToAllowASinglePartyToTeeOff() {
		clubHouse.arrive(PARTY_OF_FOUR);
		assertGroup(group(PARTY_OF_FOUR));
		clubHouse.arrive(PARTY_OF_THREE);
		assertGroup(group(PARTY_OF_THREE));
		clubHouse.arrive(PARTY_OF_TWO);
		assertGroup(group(PARTY_OF_TWO));
		clubHouse.arrive(PARTY_OF_ONE);
		assertGroup(group(PARTY_OF_ONE));
	}

	@Test
	public void shouldBeAbleToCombineParties() {
		clubHouse.arrive(PARTY_OF_TWO);
		clubHouse.arrive(PARTY_OF_TWO);
		assertGroup(group(PARTY_OF_TWO, PARTY_OF_TWO));

		clubHouse.arrive(PARTY_OF_ONE);
		clubHouse.arrive(PARTY_OF_THREE);
		assertGroup(group(PARTY_OF_ONE, PARTY_OF_THREE));

		clubHouse.arrive(PARTY_OF_THREE);
		clubHouse.arrive(PARTY_OF_ONE);
		assertGroup(group(PARTY_OF_THREE, PARTY_OF_ONE));

		clubHouse.arrive(PARTY_OF_ONE);
		clubHouse.arrive(PARTY_OF_TWO);
		clubHouse.arrive(PARTY_OF_ONE);
		assertGroup(group(PARTY_OF_ONE, PARTY_OF_TWO, PARTY_OF_ONE));
	}
	
	@Test
	public void shouldBeAbleToSkipLargeParties() {
		clubHouse.arrive(PARTY_OF_ONE);
		clubHouse.arrive(PARTY_OF_FOUR);
		clubHouse.arrive(PARTY_OF_ONE);
		assertGroup(group(PARTY_OF_ONE, PARTY_OF_ONE));
		assertGroup(group(PARTY_OF_FOUR));
	}

	@Test
	public void shouldBeAbleToTakeABreak() {
		assertGroup(Collections.EMPTY_LIST);
	}
	
	private Collection group(Integer ... parties) {
		Collection<Integer> group = new ArrayList<Integer>();
		group.addAll(Arrays.asList(parties));
		return group;
	}
	
	private void assertGroup(Collection group) {
		assertEquals(group, clubHouse.release());
	}
}
