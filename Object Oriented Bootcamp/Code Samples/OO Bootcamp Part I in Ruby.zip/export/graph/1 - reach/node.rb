module Bootcamp
  module Graph
    
    # Understands its neighors
    class Node
    
      def initialize(name)
        @name = name
        @neighbors = []
      end
      
      def connect_to(neighbor)
        @neighbors << neighbor
      end
      
      def reach?(destination)
        _reach?(destination, [])
      end
      
      protected
      def _reach?(destination, visited_nodes)
        return true if self == destination
        return false if visited_nodes.include?(self)
        visited_nodes << self
        @neighbors.detect() {|n| n._reach?(destination, visited_nodes)}
      end
      
    end

  end
end