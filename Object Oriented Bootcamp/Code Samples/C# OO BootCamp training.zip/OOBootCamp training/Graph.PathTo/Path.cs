﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;


namespace Graph.PathTo
{
    public class Path
    {
        public static readonly Path NonExisting = new Path(new List<Node>());

        public static Path EmptyFrom(Node start)
        {
            return new Path(new List<Node>() { start });   
        }
        
        private IList<Node> _hop;

        public Path(IList<Node> hop)
        {
            if (hop == null)
            {
                throw new ArgumentNullException("hop");
            }

            _hop = new ReadOnlyCollection<Node>(hop);
        }

        public int HopCount { get { return _hop.Count -1;  } }

        public IList<Node> Hop { get { return _hop; } }

        public static Path operator+ (Path leftValue, Path rightValue)
        {
            return new Path(new List<Node>(leftValue._hop.Concat(rightValue._hop)));
        }

        protected bool Equals(Path other)
        {
            return _hop.SequenceEqual(other._hop);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Path) obj);
        }

        public override int GetHashCode()
        {
            return _hop.GetHashCode();
        }

        public override string ToString()
        {
            return string.Join(", ", _hop.Select(node => node.Name));
        }
    }
}
