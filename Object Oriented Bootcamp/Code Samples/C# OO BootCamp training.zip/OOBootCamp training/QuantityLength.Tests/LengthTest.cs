﻿using NUnit.Framework;

namespace QuantityLength.Tests
{
    [TestFixture]
    public class LengthTest
    {
        private Length _tenFeet;
        private Length _anotherTenFeet;
        private Length _twentyFeet;

        private Length _tenInches;
        private Length _anotherTenInches;
        private Length _twentyInches;
        private Length _hundredtwentyInches;


        [SetUp]
        public void SetUp()
        {
            _tenFeet = new Length(UnitOfLength.Feet, 10);
            _anotherTenFeet = new Length(UnitOfLength.Feet, 10);
            _twentyFeet = new Length(UnitOfLength.Feet, 20);

            _tenInches = new Length(UnitOfLength.Inch, 10);
            _anotherTenInches = new Length(UnitOfLength.Inch, 10);
            _twentyInches = new Length(UnitOfLength.Inch, 20);
            _hundredtwentyInches = new Length(UnitOfLength.Inch, 120);
        }

        [Test]
        public void Two_lengths_in_feet_with_the_same_value_should_be_equivalent()
        {
            Assert.That(_tenFeet.IsEquivalentTo(_anotherTenFeet), Is.True);
        }

        [Test]
        public void Two_lengths_in_feet_with_different_values_should_not_be_equivalent()
        {
            Assert.That(_tenFeet.IsEquivalentTo(_twentyFeet), Is.False);
        }

        [Test]
        public void Two_lengths_in_inches_with_the_same_value_should_be_equivalent()
        {
            Assert.That(_tenInches.IsEquivalentTo(_anotherTenInches), Is.True);
        }

        [Test]
        public void Two_lengths_in_inches_with_different_values_should_not_be_equivalent()
        {
            Assert.That(_tenInches.IsEquivalentTo(_twentyInches), Is.False);
        }

        [Test]
        public void Ten_feet_and_ten_inches_should_not_be_equivalent()
        {
            Assert.That(_tenFeet.IsEquivalentTo(_tenInches), Is.False);
        }

        [Test]
        public void Ten_feet_and_hundredtwenty_inches_should_be_equivalent()
        {
            Assert.That(_tenFeet.IsEquivalentTo(_hundredtwentyInches), Is.True);
        }

        [Test]
        public void Twenty_feet_and_hundredtwenty_inches_should_not_be_equivalent()
        {
            Assert.That(_twentyFeet.IsEquivalentTo(_hundredtwentyInches), Is.False);
        }

    }
}
