package parking;

/**
 * 	Understands communication of a car not being found in a ParkingLot.
 */
public class CarNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 9066203362905888834L;

	public CarNotFoundException(Object car) {
		super("Car " + car + " not found in any lot.");
	}
	
	

}
