module Bootcamp
  module Graph
    
    # Understands its neighors
    class Node
      NO_PATH = 1.0/0.0
    
      def initialize(name)
        @name = name
        @links = []
      end
      
      def connect_to(neighbor, cost=0)
        @links << Link.new(neighbor, cost)
      end
      
      def reach?(destination)
        _cost(destination, [], $HOP_COUNT) != NO_PATH
      end

      def hop_count(destination)
        cost_with_strategy(destination, $HOP_COUNT)
      end

      def cost(destination)
        cost_with_strategy(destination, $ACTUAL_COST)
      end

      private
      def cost_with_strategy(destination, cost)
        result = _cost(destination, [], cost)
        raise NoPathError.new(self, destination) if result == NO_PATH
        result
      end
      
      public
      def _cost(destination, visited_nodes, cost)
        return 0 if self == destination
        return NO_PATH if visited_nodes.include?(self) || @links.empty?
        (visited_nodes = visited_nodes.dup) << self
        @links.collect {|link| link._cost(destination, visited_nodes, cost)}.min
      end
      
    end

  end
end