package com.obc.parkinglot;


interface ParkingLotObserver {

	public abstract void notifyFull(ParkingLot lot);

	public abstract void notifyHasSpace(ParkingLot lot);

}