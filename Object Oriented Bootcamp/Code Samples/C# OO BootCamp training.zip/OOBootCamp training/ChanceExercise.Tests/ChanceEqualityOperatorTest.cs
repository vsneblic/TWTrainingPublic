﻿using System;
using NUnit.Framework;

namespace ChanceExercise.Tests
{
    [TestFixture]
    class ChanceEqualityOperatorTest
    {
        private Chance _anyChance;
        private double _anyProbability;

        [SetUp]
        public void SetUp()
        {
            _anyChance = new Chance(0.579);
            _anyProbability = 0.9876;
        }

        [Test]
        public void Two_different_chances_with_the_same_probability_are_equal()
        {
            Assert.That(new Chance(_anyProbability), Is.EqualTo(new Chance(_anyProbability)));
        }

        [Test]
        public void A_non_null_chance_should_be_equal_to_self()
        {
            Assert.That(_anyChance, Is.EqualTo(_anyChance));
        }

        [Test]
        public void A_chance_should_be_different_from_null()
        {
            Assert.That(_anyChance, Is.Not.EqualTo(null));
        }
    }
}
