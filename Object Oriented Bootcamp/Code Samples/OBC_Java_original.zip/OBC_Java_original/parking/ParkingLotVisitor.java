package parking;

public interface ParkingLotVisitor {

	public abstract String print();
	public abstract void visit(ParkingSpaces spaces);
	public void previsit(Attendant attendant);
	public void postvisit(Attendant attendant);
	public void previsit(ParkingLot lot);
	public void postvisit(ParkingLot lot);

}